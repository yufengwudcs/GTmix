//
//  GenealogicalNetworkSearch2.hpp
//  
//
//  Created by Yufeng Wu on 4/21/19.
//
//

#ifndef GenealogicalNetworkSearch2_hpp
#define GenealogicalNetworkSearch2_hpp

#include "GenealogicalNetwork.h"

class PhylogenyTreeBasic;
class MarginalTree;

#if 0

//***********************************************************************************
// Filtering

class GenealogicalNetFilter
{
public:
    GenealogicalNetFilter(GenealogicalNetwork *pInit);
    
    bool ScoreNetwork( GenealogicalNetwork *pNet );
    void MarkNetwork( GenealogicalNetwork *pNet, bool fNoWorse );
    void AdoptNet( GenealogicalNetwork *pNetToAdopt );
    
private:
    void FindNovelClustersInNet( GenealogicalNetwork *pNet, set<set<int> > &setClus );
    void FindClustersInNet( GenealogicalNetwork *pNet, set<set<int> > &setClus );
    
    map< set<int>, int> mapClusterSupport;      // how likely a cluster would improve the score
    GenealogicalNetwork *pNetCurr;
};
#endif


//***********************************************************************************
// Search for optimal network

class GenealogicalNetworkSearch2
{
public:
    GenealogicalNetworkSearch2(vector<PhylogenyTreeBasic *> &listGeneTreesIn, GenealogicalNetwork &networkInitIn, TaxaMapper &mapperTaxaIdsIn);
    ~GenealogicalNetworkSearch2();
    double Search(int numMixNodes=1);
    void InfMixPops( set<string> &setMixTaxaUser );
    GenealogicalNetwork *GetBestNet();
    void SetMaxNumMixNodes(int mn) { maxNumMixNodes = mn; }
    int GetMaxNumMixNodes() const { return maxNumMixNodes; }
    void SetHeuSearch(bool fHeu) { fHeuSearch = fHeu; }
    static void SetOutgroup(int og);
    static int GetOutgroup();
    
private:
    // implementation
    void FindMixTaxaImp( vector<int> &setMixTaxa );
    int FindOneMixTaxonFrom( const set<int> &setTaxaCurr );
    double ScoreForNetwork(const vector<PhylogenyTreeBasic *> &listTrees, GenealogicalNetwork *pNetCurr);
    double ScoreForNetworkMDC(const vector<PhylogenyTreeBasic *> &listTrees, GenealogicalNetwork *pNetCurr);
    double ExploreNgbrs();
    
    // helpers
    void SetCurLogProb(double lp) { logprobBestCurr = lp; }
    double GetCurrBestLogprob() const { return logprobBestCurr; }
    void GetAllTaxa(set<int> &setTaxa) const;
    void GetReducedGenetreesForSubsetTaxa( const set<int> &setTaxaSub, vector<PhylogenyTreeBasic *> &listGeneTreesSub ) const;
    bool IsNetworkOGGood( const GenealogicalNetwork &netTest );
    static int ScoreMDCGTandST( PhylogenyTreeBasic *pGeneTree, MarginalTree *pST );
    
    GenealogicalNetwork *pnetworkOpt;
    vector<PhylogenyTreeBasic *> &listGeneTrees;
    GenealogicalNetwork &networkInit;
    TaxaMapper &mapperTaxaIds;
    int maxNumMixNodes;
    double logprobBestCurr;
    bool fHeuSearch;
    static int taxonOutgroup;
};



#endif /* GenealogicalNetworkSearch2_hpp */
