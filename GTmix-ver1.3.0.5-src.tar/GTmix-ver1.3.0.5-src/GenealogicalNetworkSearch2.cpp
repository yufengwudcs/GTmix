//
//  GenealogicalNetworkSearch2.cpp
//  
//
//  Created by Yufeng Wu on 4/21/19.
//
//

#include "GenealogicalNetworkSearch2.hpp"
#include "GenealogicalNetworkLenOpt.h"
#include "PhylogenyTreeBasic.h"
#include "MarginalTree.h"
#include "Utils4.h"
#include "DeepCoalescence.h"
#include <cmath>
#include <string>

const double MIN_INC_RATIO = 1.00001;

#if 0

//***********************************************************************************
// Filtering


GenealogicalNetFilter :: GenealogicalNetFilter(GenealogicalNetwork *pInit)
{
    //
    pNetCurr = pInit;
//cout << "** Init net: ";
//pNetCurr->DumpMargTrees(false);
}

bool GenealogicalNetFilter :: ScoreNetwork( GenealogicalNetwork *pNet )
{
//cout << "Score network: ";
//pNet->DumpMargTrees(false);
    // return true if this is likely a good start; false other wise
    set<set<int> > setClusNovel;
    FindNovelClustersInNet(pNet, setClusNovel);
    // score these clusters
    int score = 0;
    for(set<set<int> > :: iterator it = setClusNovel.begin(); it != setClusNovel.end(); ++it)
    {
        if( mapClusterSupport.find(*it) != mapClusterSupport.end() )
        {
            score += mapClusterSupport[*it];
        }
    }
    if( score >= 0 )
    {
//cout << "Good candidate: \n";
        return true;
    }
    else
    {
//cout << "Bad candidate: \n";
        return false;
    }
}

void GenealogicalNetFilter :: MarkNetwork( GenealogicalNetwork *pNet, bool fNoWorse )
{
#if 0
cout << "Mark network: ";
if(fNoWorse)
{
cout << "UPVOTE  \n";
}
else
{
cout << "DOWNVOTE  \n";
}
pNet->DumpMargTrees(false);
#endif
    // find all novel clusters, mark them
    set<set<int> > setClusNovel;
    FindNovelClustersInNet(pNet, setClusNovel);
    // score these clusters
    for(set<set<int> > :: iterator it = setClusNovel.begin(); it != setClusNovel.end(); ++it)
    {
        int score = 0;
        if( mapClusterSupport.find(*it) != mapClusterSupport.end() )
        {
            score = mapClusterSupport[*it];
        }
        if( fNoWorse == true )
        {
            ++score;
        }
        else
        {
            --score;
        }
        mapClusterSupport[*it] = score;
    }
}

void GenealogicalNetFilter :: AdoptNet( GenealogicalNetwork *pNetToAdopt )
{
    //
    pNetCurr = pNetToAdopt;
//cout << "**** Adopt net: ";
//pNetCurr->DumpMargTrees(false);
    
// current score
//cout << "Current set of cluster support...\n";
//for(map<set<int>,int> :: iterator it = mapClusterSupport.begin(); it != mapClusterSupport.end(); ++it)
//{
//cout << "[" << it->second << "]: ";
//DumpIntSet(it->first);
//}
}

void GenealogicalNetFilter :: FindNovelClustersInNet( GenealogicalNetwork *pNet, set<set<int> > &setClus )
{
    //
    setClus.clear();
    set<set<int> > setClusThis, setClusOrig;
    FindClustersInNet(pNet, setClusThis);
    FindClustersInNet(pNetCurr, setClusOrig);
    for(set<set<int> > :: iterator it = setClusThis.begin(); it != setClusThis.end(); ++it)
    {
        if( setClusOrig.find(*it) == setClusOrig.end() )
        {
            setClus.insert(*it);
//cout << "Novel clsuter: ";
//DumpIntSet(*it);
        }
    }
}

void GenealogicalNetFilter :: FindClustersInNet( GenealogicalNetwork *pNet, set<set<int> > &setClus )
{
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    pNet->RetriveAllMarginalTrees( mapMargTreesWithFreq );
    
    vector<MarginalTree *> listMargTrees;
    for(map<GenealogicalNetworkMTreeCode,GenealogicalNetworkMTreeInfo> :: iterator it=mapMargTreesWithFreq.begin(); it!=mapMargTreesWithFreq.end(); ++it)
    {
        listMargTrees.push_back(it->second.GetMargTree());
    }
    
    //
    setClus.clear();
    for(int i=0; i<(int)listMargTrees.size(); ++i)
    {
        vector<set<int> > setSplits;
        listMargTrees[i]->FindAllSplits( setSplits );
        for(int j=0;j<(int)setSplits.size(); ++j)
        {
            setClus.insert(setSplits[j]);
        }
    }
}

#endif



//***********************************************************************************
// Search for optimal network

const int DEF_MAX_NUM_NET_NODES = 1;
int GenealogicalNetworkSearch2 :: taxonOutgroup = -1;

GenealogicalNetworkSearch2 :: GenealogicalNetworkSearch2(vector<PhylogenyTreeBasic *> &listGeneTreesIn, GenealogicalNetwork &networkInitIn, TaxaMapper &mapperIdTaxaIn) : pnetworkOpt(NULL), listGeneTrees(listGeneTreesIn), networkInit(networkInitIn), mapperTaxaIds(mapperIdTaxaIn),  maxNumMixNodes( DEF_MAX_NUM_NET_NODES ), logprobBestCurr(MAX_NEG_DOUBLE_VAL), fHeuSearch(false)
{
}

GenealogicalNetworkSearch2 :: ~GenealogicalNetworkSearch2()
{
    //
    if( pnetworkOpt != NULL )
    {
        delete pnetworkOpt;
    }
}

// search for opt network
double GenealogicalNetworkSearch2 :: Search(int numMixNodes)
{
    //
    SetMaxNumMixNodes(numMixNodes);
    vector<int> setMixTaxa;
    FindMixTaxaImp(setMixTaxa);
    
    //
    if( pnetworkOpt == NULL )
    {
        pnetworkOpt = networkInit.Copy();
    }
    GenealogicalNetworkLenOpt probInitCalc( *pnetworkOpt, listGeneTrees );
    double probCurBest = probInitCalc.Optimize();
    
    // now add the admix nodes
    for(int i=0; i<(int)setMixTaxa.size(); ++i)
    {
        probCurBest = MAX_NEG_DOUBLE_VAL;
        
        int tidMix = setMixTaxa[i];
//cout << "Search: addiing this mixing taxon: " << tidMix << endl;
        GenealogicalNetworkNode *pLeaf = pnetworkOpt->GetLeafWithTaxon(tidMix);
        YW_ASSERT_INFO( pLeaf != NULL, "Cannot be null" );
        GenealogicalNetworkBranch *pBrLeaf = pLeaf->GetAnces1();
        YW_ASSERT_INFO(pBrLeaf!=NULL, "Leaf branch cannot be null");
        vector<GenealogicalNetwork *> listNetsOneNewMix;
        pnetworkOpt->RetriveNgbrNetsOneNewMixForEdge( pBrLeaf, listNetsOneNewMix );
//cout << "Number of admixture network candidates: " << listNetsOneNewMix.size() << endl;
        
        // find the best net to go with
        vector<double> listLogProbs;
        for(int j=0; j<(int)listNetsOneNewMix.size(); ++j)
        {
            double probStep = ScoreForNetwork(listGeneTrees, listNetsOneNewMix[j]);
            //double probStep = ScoreForNetworkMDC(listGeneTrees, listNetsOneNewMix[j]);
            listLogProbs.push_back(probStep);
        }
//cout << "List of prob of candidate networks: ";
//DumpDoubleVec(listLogProbs);
        
        int maxProbPos = -1;
        bool fContSearch = false;
        if( listNetsOneNewMix.size() > 0 )
        {
            int maxProbPosStep = FindMaxValPositionFromList( listLogProbs );
//cout << "Max prob pos: " << maxProbPosStep << endl;
//cout << "Max prob: " << listLogProbs[maxProbPosStep] << ", probCurBest: " << probCurBest << endl;
            double probBestNgbr = listLogProbs[maxProbPosStep];
            //cout << "!Best ngbr prob: " << probBestNgbr << endl;
            
            if( probBestNgbr >= probCurBest + log(MIN_INC_RATIO) )
            {
                maxProbPos = maxProbPosStep;
                
                // now optimize branch length of the selected one
                //if( fFastSearch == false )
                //{
                probCurBest = probBestNgbr;
                //}
                //else
                //{
                //    GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[maxProbPos], listGeneTrees);
                //    double probBestNgbrLenOpt = opt.Optimize();
                    // improvement found
                    //probCurBest = probBestNgbr;
                //    probCurBest = probBestNgbrLenOpt;
                //}
//cout << "maxProbPosStep: " << maxProbPosStep << ", size of net candidates: " << listNetsOneNewMix.size() << endl;
                delete pnetworkOpt;
                pnetworkOpt = listNetsOneNewMix[maxProbPosStep];
                fContSearch = true;
//cout << "UPDATING THE CURRENT NETWORK TO: ";
// pnetworkOpt->DumpMargTrees(false);
                //pnetworkOpt->Dump();
            }
        }
        
        for(int k=0; k<(int)listNetsOneNewMix.size(); ++k)
        {
            //if( k != maxProbPos || fContSearch == false )
            if( k != maxProbPos  )
            {
                delete listNetsOneNewMix[k];
            }
        }
        if( fContSearch == false )
        {
            break;
        }
    }
    
//#if 0
    // optimize again
    GenealogicalNetworkLenOpt probInitCalc2( *pnetworkOpt, listGeneTrees );
    probCurBest = probInitCalc2.Optimize();
//#endif
    
    SetCurLogProb(probCurBest);
    
    // now try to improve the network
    //if( fHeuSearch == false )
    //{
        probCurBest = ExploreNgbrs();
    //}
    return probCurBest;
}

void GenealogicalNetworkSearch2 :: InfMixPops( set<string> &setMixTaxaUser )
{
    //
    setMixTaxaUser.clear();
    vector<int> setMixTaxa;
    FindMixTaxaImp(setMixTaxa);
    for(vector<int> :: iterator it = setMixTaxa.begin(); it != setMixTaxa.end(); ++it)
    {
        string midUser = mapperTaxaIds.GetString( *it );
        setMixTaxaUser.insert(midUser);
    }
}

//***********************************************************************************

void GenealogicalNetworkSearch2 :: FindMixTaxaImp( vector<int> &setMixTaxa )
{
    //
    set<int> setTaxaCurr;
    GetAllTaxa(setTaxaCurr);
    
    // now search for mix taxa one by one
    setMixTaxa.clear();
    for(int na=0; na<this->maxNumMixNodes; ++na)
    {
        int taxonMix = FindOneMixTaxonFrom(setTaxaCurr);
//cout << "FindOneMixTaxonFrom: taxonMix: " << taxonMix << endl;
        if( taxonMix < 0 )
        {
            break;
        }
        setMixTaxa.push_back(taxonMix);
        setTaxaCurr.erase(taxonMix);
    }
}

int GenealogicalNetworkSearch2 :: FindOneMixTaxonFrom( const set<int> &setTaxaCurr )
{
    // consider all taxon in the set one by one to see which one fits more a mixture
    if( setTaxaCurr.size() <= 1 )
    {
        // nothing left
        return -1;
    }
    vector<int> listMultiplicityTrees;
    for(int tr=0; tr<(int)listGeneTrees.size(); ++tr)
    {
        listMultiplicityTrees.push_back(1);
    }
    
    // get the overall MDC
    const int DEF_MDC_LEVEL= 1;
    DeepCoalescence mdcOrigCalc(listGeneTrees, DEF_MDC_LEVEL);
    mdcOrigCalc.SetMultiplictyofTrees(listMultiplicityTrees);
    int mdcOrig = mdcOrigCalc.FindMDC();
//cout << "MCD orig: " << mdcOrig << endl;
    
    //int mdcMin = HAP_MAX_INT;
    //int res = -1;
    vector<pair<int,int> > listMDCLevels;
    vector<int> listTaxa;
    for(set<int> :: iterator it = setTaxaCurr.begin(); it != setTaxaCurr.end(); ++it )
    {
        int taxonCurr = *it;
        set<int> setTaxaStep = setTaxaCurr;
        setTaxaStep.erase(taxonCurr);
        
        vector<PhylogenyTreeBasic *> listPhyTreesSub;
        GetReducedGenetreesForSubsetTaxa( setTaxaStep, listPhyTreesSub );
        
        // convert tree to consecutive zero-based
        TaxaMapper taxonMapper;
        ConvPhyloTreesToZeroBasedId( listPhyTreesSub, &taxonMapper);
//cout << "Curr taxon: " << taxonCurr << ", set of taxa remaining: ";
//DumpIntSet( setTaxaStep );
//for(int tr=0; tr<(int)listPhyTreesSub.size(); ++tr)
//{
//string strNW;
//listPhyTreesSub[tr]->ConsNewickSorted(strNW);
//cout << "Tree: " << strNW << endl;
//}
        
        //
        DeepCoalescence mdc(listPhyTreesSub, DEF_MDC_LEVEL);
        mdc.SetMultiplictyofTrees(listMultiplicityTrees);
        int mdcVal = mdc.FindMDC();
        YW_ASSERT_INFO(listPhyTreesSub.size() > 0, "Cannot be empty list");
        int numLvsStep = listPhyTreesSub[0]->GetNumLeaves();
        pair<int,int> pp(mdcVal, numLvsStep);
        listMDCLevels.push_back(pp);
        listTaxa.push_back(taxonCurr);
        //if( mdcVal < mdcMin)
        //{
        //    mdcMin = mdcVal;
        //    res = taxonCurr;
        //}
        
//cout << "MDC: " << mdcVal;
//cout << "  for curr taxon: " << taxonCurr << endl;
        
//cout << "Curr taxon: " << taxonCurr << ", set of taxa remaining: ";
//DumpIntSet( setTaxaStep );
        for(int tr=0; tr<(int)listPhyTreesSub.size(); ++tr)
        {
//string strNW;
//listPhyTreesSub[tr]->ConsNewickSorted(strNW);
//cout << "Tree: " << strNW << endl;
            delete listPhyTreesSub[tr];
        }
    }
    
    int res = -1;
    double mdcUnitOpt = -1.0;
    for(int i=0; i<(int)listMDCLevels.size(); ++i)
    {
        double mdcUnitStep = ((double)(  mdcOrig-listMDCLevels[i].first ))/listMDCLevels[i].second;
        if(mdcUnitOpt < mdcUnitStep)
        {
            mdcUnitOpt = mdcUnitStep;
            res = listTaxa[i];
        }
    }
    YW_ASSERT_INFO(res >= 0, "Fail to find initial taxa");
//cout << "** MDC-opt admixure taxon: " << res << endl;
    
    return res;
}

double GenealogicalNetworkSearch2 :: ScoreForNetwork(const vector<PhylogenyTreeBasic *> &listTrees, GenealogicalNetwork *pNetCurr)
{
    // score
    vector<PhylogenyTreeBasic *> &listTreesUse = const_cast<vector<PhylogenyTreeBasic *> & >(listTrees);
    GenealogicalNetworkLenOpt opt(*pNetCurr, listTreesUse);
    return opt.CalcProb();
}

double GenealogicalNetworkSearch2 :: ScoreForNetworkMDC(const vector<PhylogenyTreeBasic *> &listTrees, GenealogicalNetwork *pNetCurr)
{
    // get marginal trees embedded in the network
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    pNetCurr->RetriveAllMarginalTrees( mapMargTreesWithFreq );
    
    vector<MarginalTree *> listMargTrees;
    for(map<GenealogicalNetworkMTreeCode,GenealogicalNetworkMTreeInfo> :: iterator it=mapMargTreesWithFreq.begin(); it!=mapMargTreesWithFreq.end(); ++it)
    {
        listMargTrees.push_back(it->second.GetMargTree());
    }
    
    // for each tree, take the best (lowest) MDC
    int res = 0;
    for(int i=0; i<(int)listTrees.size(); ++i)
    {
        int costStep = HAP_MAX_INT;
        for(int j=0; j<(int)listMargTrees.size(); ++j)
        {
            int cstep = ScoreMDCGTandST(listTrees[i], listMargTrees[j]);
            if( cstep < costStep )
            {
                costStep = cstep;
            }
        }
        res += costStep;
    }
    
    
    //tbd;
    return -1.0*res;
}

double GenealogicalNetworkSearch2 :: ExploreNgbrs()
{
    YW_ASSERT_INFO(pnetworkOpt != NULL, "Opt network is not initialized");
    //GenealogicalNetFilter netFilter(pnetworkOpt);
    
    
    //double probCurBest = MAX_NEG_DOUBLE_VAL;
    double probCurBest = GetCurrBestLogprob();
    while(true)
    {
#if 0
        cout << "--Processing current network (w/ prob: " << probCurBest << "): \n";
        pnetworkOpt->DumpMargTrees(false);
        pnetworkOpt->Dump();
#endif
        //
        vector<GenealogicalNetwork *> listNgbrNetsDist1;
        pnetworkOpt->RetriveNgbrNetsOneEvt( listNgbrNetsDist1 );
        
        // first find new networks
        vector<int> listNgbrNetPos;
        vector<GenealogicalNetwork *> listNgbrNetsDist1New;
        for(int i=0; i<(int)listNgbrNetsDist1.size(); ++i)
        {
            //bool fFoundBefore = IsNetProcBefore( listNgbrNetsDist1[i] );
            bool fOGOK = IsNetworkOGGood( *listNgbrNetsDist1[i] );
            
            if( fOGOK )
            {
                listNgbrNetsDist1New.push_back( listNgbrNetsDist1[i] );
                listNgbrNetPos.push_back(i);
                
                // mark how many nets we have processed
                //infoSearch.ProcNet( listNgbrNetsDist1[i] );
            }
            else
            {
                //infoSearch.SkipNet( listNgbrNetsDist1[i] );
            }
        }
        
        
        // find ngbr networks (no adding new mix nodes)
        vector<double> listLogProbNgbrNets;
        
        for(int i=0; i<(int)listNgbrNetsDist1New.size(); ++i)
        {
            int netIndex = listNgbrNetPos[i];
#if 0
            cout << "&&&&&&&&&&&&&&&&&&Processing ngbr network " << netIndex << endl;
            listNgbrNetsDist1[netIndex]->DumpMargTrees(false);
            listNgbrNetsDist1[netIndex]->Dump();
#endif
            bool fSearch = true;
            
            if( fHeuSearch == true )
            {
            //    fSearch = netFilter.ScoreNetwork( listNgbrNetsDist1[netIndex] );
            }
            
            if( fSearch == true )
            {
                GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[netIndex], listGeneTrees);
                //double logprobBest = opt.Optimize();
                
                //if( fFastSearch == false )
                //{
                //    double logprobBest = opt.Optimize();
                //    listLogProbNgbrNets.push_back( logprobBest );
                //    //cout << "(1a) Network ngbr " << i << ": optimized likelihood: " << logprobBest << endl;
                //}
                //else
                //{
                // YW: Feb 18, 2016: don't optimize branch length after a change of topology
                double logprobChange = opt.CalcProb();
                //listLogProbNgbrNets.push_back( logprobBest );
                listLogProbNgbrNets.push_back(logprobChange);
                //cout << "(1) Network ngbr " << i << ": un-optimized likelihood: " << logprobChange << endl;
                //}
                
                
                // mark it
                //bool fNoWorse = (logprobChange >= probCurBest);
                //netFilter.MarkNetwork( listNgbrNetsDist1[netIndex], fNoWorse );
            }
        }
        
        // if nothing left, done
        int maxProbPos = -1;
        bool fContSearch = false;
        if( listLogProbNgbrNets.size() > 0 )
        {
            int maxProbPosStep = FindMaxValPositionFromList( listLogProbNgbrNets );
            double probBestNgbr = listLogProbNgbrNets[maxProbPosStep];
            //cout << "!Best ngbr prob: " << probBestNgbr << endl;
            
            if( probBestNgbr >= probCurBest + log(MIN_INC_RATIO) )
            {
                maxProbPos = listNgbrNetPos[maxProbPosStep];
                
                // now optimize branch length of the selected one
                //if( fFastSearch == false )
                //{
                //    probCurBest = probBestNgbr;
                //}
                //else
                //{
                GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[maxProbPos], listGeneTrees);
                double probBestNgbrLenOpt = opt.Optimize();
                
                // improvement found
                //probCurBest = probBestNgbr;
                probCurBest = probBestNgbrLenOpt;
                //}
                
                delete pnetworkOpt;
                pnetworkOpt = listNgbrNetsDist1[maxProbPos];
                fContSearch = true;
                //cout << "UPDATING THE CURRENT NETWORK TO: ";
                //pnetworkOpt->Dump();
                
                //netFilter.AdoptNet(pnetworkOpt);
            }
        }
        
        for(int i=0; i<(int)listNgbrNetsDist1.size(); ++i)
        {
            if( i != maxProbPos || fContSearch == false )
            {
                delete listNgbrNetsDist1[i];
            }
        }
        //cout << "@@@@@@@@@@@@@@@ Current best log-likelihood: " << probCurBest << endl;
        //cout << "Best network: ";
        //pnetworkOpt->DumpMargTrees(false);
        if( fContSearch == false )
        {
            break;
        }
    }
    
    return probCurBest;
}

//***********************************************************************************

GenealogicalNetwork * GenealogicalNetworkSearch2 :: GetBestNet()
{
    return pnetworkOpt;
}

void GenealogicalNetworkSearch2 :: SetOutgroup(int r)
{
    //cout << "Interval outgroup id: " << r << endl;
    taxonOutgroup = r;
}
int GenealogicalNetworkSearch2 :: GetOutgroup()
{
    return taxonOutgroup;
}

void GenealogicalNetworkSearch2 :: GetAllTaxa(set<int> &setTaxa) const
{
    YW_ASSERT_INFO(listGeneTrees.size() > 0, "Must have some trees");
    listGeneTrees[0]->GetLeafIntLabels( setTaxa );
}

void GenealogicalNetworkSearch2 :: GetReducedGenetreesForSubsetTaxa( const set<int> &setTaxaSub, vector<PhylogenyTreeBasic *> &listGeneTreesSub ) const
{
    //
    listGeneTreesSub.clear();
    for(int tr=0; tr<(int)listGeneTrees.size(); ++tr)
    {
        PhylogenyTreeBasic *ptreesub = ConsPhyTreeSubsetTaxa( listGeneTrees[tr], setTaxaSub );
        listGeneTreesSub.push_back(ptreesub);
    }
}

bool GenealogicalNetworkSearch2 :: IsNetworkOGGood( const GenealogicalNetwork &netTest )
{
    // if outgroup is set, then each embedded tree should be consistent with the outgroup: yes each
    if( taxonOutgroup < 0 )
    {
        return true;
    }
    //cout << "IsNetworkOGGood: network is ";
    //netTest.DumpMargTrees(false);
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    netTest.RetriveAllMarginalTrees( mapMargTreesWithFreq );
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapMargTreesWithFreq.begin(); it != mapMargTreesWithFreq.end(); ++it )
    {
        MarginalTree *ptree = it->second.GetMargTree();
        if( ptree->IsOutgroup( taxonOutgroup ) == false )
        {
            return false;
        }
    }
    return true;
}

int GenealogicalNetworkSearch2 :: ScoreMDCGTandST( PhylogenyTreeBasic *pGeneTree, MarginalTree *pST )
{
    // get all clades of ST
    vector<set<int> > leafNodeLabels ;
    pST->ConsDecedentLeavesInfoLabels( leafNodeLabels );
    
    // cons string-based labels
    vector<set<string> > leafNodeLabelsUse;
    for(int i=0;i<(int)leafNodeLabels.size(); ++i)
    {
        //
        set<string> ss;
        for(set<int>::iterator it=leafNodeLabels[i].begin(); it!=leafNodeLabels[i].end(); ++it)
        {
            string str = std::to_string( *it );
            ss.insert(str);
        }
        leafNodeLabelsUse.push_back(ss);
    }
    
    // now get the
    int res = 0;
    
    //
    set<set<TreeNode *> > setClades;
    pGeneTree->GetAllCladeNodess(setClades);
    for(int i=0;i<(int)leafNodeLabelsUse.size(); ++i)
    {
#if 0
cout << "Taxa: ";
for(set<string>:: iterator it=leafNodeLabelsUse[i].begin(); it!=leafNodeLabelsUse[i].end();++it)
{
cout << *it << " ";
}
cout << endl;
#endif
        set<TreeNode *> setLvNodes;
        pGeneTree->GetLeavesWithLabels( leafNodeLabelsUse[i], setLvNodes );
        
        //
        set< set<TreeNode *> > setSubtreeClades;
        PhylogenyTreeBasic :: GroupLeavesToSubtrees( setLvNodes,  setClades, setSubtreeClades );
        res += setSubtreeClades.size()-1;
//cout << "Curr MDC score: " << setSubtreeClades.size()-1 << endl;
    }
    string strNW;
    pGeneTree->ConsNewickSorted(strNW);
//cout << "For gene tree: " << strNW << ", marginalt ree: " << pST->GetNewickSorted(false) << ", MDC = " << res << endl;
    return res;
}

