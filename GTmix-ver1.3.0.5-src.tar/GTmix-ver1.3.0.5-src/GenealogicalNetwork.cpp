//
//  GenealogicalNetwork.cpp
//  
//
//  Created by Yufeng Wu on 12/21/15.
//
//

#include "GenealogicalNetwork.h"
#include "Utils4.h"
#include "MarginalTree.h"
#include "PhylogenyTreeBasic.h"
#include "UnWeightedGraph.h"
#include <string>

//***********************************************************************************
// Network node

int GenealogicalNetworkNode :: idToUseNext = 1;

GenealogicalNetworkNode :: GenealogicalNetworkNode(): taxonId(-1), pDescBranch1(NULL), pDescBranch2(NULL), pSrcBranch1(NULL), pSrcBranch2(NULL), ratioMix(0.0)
{
    nodeId = idToUseNext++;
}
GenealogicalNetworkNode :: ~GenealogicalNetworkNode()
{
}
bool GenealogicalNetworkNode :: IsMixNode() const
{
    return GetNumParents() == 2;
}
bool GenealogicalNetworkNode :: IsLeaf() const
{
    return GetNumChildren() == 0;
}
bool GenealogicalNetworkNode :: IsRoot() const
{
    return GetNumParents() == 0;
}
bool GenealogicalNetworkNode :: HasTaxon() const
{
    return GetTaxonId() >= 0;
}
GenealogicalNetworkNode * GenealogicalNetworkNode :: GetOtherDescNode(GenealogicalNetworkNode *pDescOne) const
{
    // get the descendent other than pDescOne
    if( GetLeftDescNode()==pDescOne )
    {
        return GetRightDescNode();
    }
    else
    {
        return GetLeftDescNode();
    }
}
int GenealogicalNetworkNode :: GetNumChildren() const
{
    int res = 0;
    if( pDescBranch1 != NULL )
    {
        ++res;
    }
    if( pDescBranch2 != NULL)
    {
        ++res;
    }
    return res;
}
GenealogicalNetworkNode * GenealogicalNetworkNode :: GetChildSingle() const
{
    // return one child
    if( pDescBranch1 != NULL)
    {
        return pDescBranch1->GetDestNode();
    }
    else if( pDescBranch2 != NULL )
    {
        return pDescBranch2->GetDestNode();
    }
    else
    {
        return NULL;
    }
}
void GenealogicalNetworkNode :: RemoveChild( GenealogicalNetworkNode *pNodeChild )
{
    pNodeChild->RemoveParent(this);
    // remove the specified child
    if( pDescBranch1 != NULL)
    {
        if( pDescBranch1->GetDestNode() == pNodeChild )
        {
            //
            //delete pDescBranch1;
            pDescBranch1 = NULL;
            return;
        }
    }
    if( pDescBranch2 != NULL )
    {
        if( pDescBranch2->GetDestNode() == pNodeChild )
        {
            //delete pDescBranch2;
            pDescBranch2 = NULL;
            return;
        }
    }
}
void GenealogicalNetworkNode :: RemoveParent( GenealogicalNetworkNode *pParent )
{
    //
    if( pSrcBranch1 != NULL)
    {
        if( pSrcBranch1->GetSrcNode() == pParent)
        {
            pSrcBranch1 = NULL;
            return;
        }
    }
    if( pSrcBranch2 != NULL)
    {
        if( pSrcBranch2->GetSrcNode() == pParent)
        {
            pSrcBranch2 = NULL;
            return;
        }
    }
}
int GenealogicalNetworkNode :: GetNumParents() const
{
    int res = 0;
    if( pSrcBranch1 != NULL )
    {
        ++res;
    }
    if( pSrcBranch2 != NULL )
    {
        ++res;
    }
    return res;
}

GenealogicalNetworkBranch * GenealogicalNetworkNode :: GetParentBrSingle() const
{
    if( pSrcBranch1 != NULL)
    {
        return pSrcBranch1;
    }
    else if( pSrcBranch2 != NULL )
    {
        return pSrcBranch2;
    }
    else
    {
        return NULL;
    }
}

GenealogicalNetworkNode * GenealogicalNetworkNode :: GetParentSingle() const
{
    if( pSrcBranch1 != NULL)
    {
        return pSrcBranch1->GetSrcNode();
    }
    else if( pSrcBranch2 != NULL )
    {
        return pSrcBranch2->GetSrcNode();
    }
    else
    {
        return NULL;
    }
}

void GenealogicalNetworkNode :: GetAllLeavesUnder( set<GenealogicalNetworkNode *> &setLeavesBelow) const
{
    //
    if(IsLeaf())
    {
        GenealogicalNetworkNode *pthis = const_cast<GenealogicalNetworkNode *>(this);
        setLeavesBelow.insert(pthis);
        return;
    }
    if( GetLeftDesc() != NULL )
    {
        GenealogicalNetworkNode *pLeft = GetLeftDescNode();
        if( pLeft != NULL )
        {
            pLeft->GetAllLeavesUnder(setLeavesBelow);
        }
    }
    if( GetRightDesc() != NULL )
    {
        GenealogicalNetworkNode *pRight = GetRightDescNode();
        if( pRight != NULL )
        {
            pRight->GetAllLeavesUnder(setLeavesBelow);
        }
    }
}

void GenealogicalNetworkNode :: GetAllLeafTaxonIdsUnder(set<string> &setLeavesIds ) const
{
    //
    setLeavesIds.clear();
    set<GenealogicalNetworkNode *> setLeavesBelow;
    GetAllLeavesUnder( setLeavesBelow );
    for( set<GenealogicalNetworkNode *> :: iterator it = setLeavesBelow.begin(); it != setLeavesBelow.end(); ++it )
    {
        string strLv = (*it)->GetTaxonStrUser();
        setLeavesIds.insert(strLv);
    }
}

bool GenealogicalNetworkNode :: IsLeftAncesBranch( GenealogicalNetworkBranch *pBr ) const
{
    if( pBr == pSrcBranch1 )
    {
        return true;
    }
    else
    {
        return false;
    }
}
void GenealogicalNetworkNode :: SetDescendents( GenealogicalNetworkBranch *pDest1, GenealogicalNetworkBranch *pDest2 )
{
    pDescBranch1 = pDest1;
    pDescBranch2 = pDest2;
}
GenealogicalNetworkNode * GenealogicalNetworkNode :: AddToSib( GenealogicalNetworkNode *pSibToBe, double lenThis, double lenSib, GenealogicalNetworkBranch * &pbrParToOld, GenealogicalNetworkBranch * &pbrParToSib )
{
    // create a new node and add this node as sibling
#if 0
cout << "AddToSib: lenThis: " << lenThis << ", lenSib: " << lenSib << ": pSibToBe: ";
pSibToBe->Dump();
cout << endl;
#endif
    GenealogicalNetworkNode *pNodeParNew = new GenealogicalNetworkNode();
    pbrParToOld = new GenealogicalNetworkBranch( pNodeParNew, this );
    pbrParToOld->SetLength(lenThis);
    pbrParToSib = new GenealogicalNetworkBranch( pNodeParNew, pSibToBe);
    pbrParToSib->SetLength(lenSib);
    pNodeParNew->SetChildBranch( pbrParToOld );
    pNodeParNew->SetChildBranch( pbrParToSib);
    this->SetParentBranch(pbrParToOld);
    pSibToBe->SetParentBranch(pbrParToSib);
    return pNodeParNew;
}
void GenealogicalNetworkNode :: SetParentBranch( GenealogicalNetworkBranch *pAnc )
{
    //
    if( pSrcBranch1 == NULL )
    {
        //
        pSrcBranch1 = pAnc;
    }
    else if( pSrcBranch2 == NULL)
    {
        pSrcBranch2 = pAnc;
    }
    else
    {
        YW_ASSERT_INFO(false, "SetParentBranch");
    }
}
void GenealogicalNetworkNode :: SetChildBranch( GenealogicalNetworkBranch *pChild)
{
#if 0
this->Dump();
cout << endl;
#endif
    //
    if( pDescBranch1 == NULL )
    {
        //
        pDescBranch1 = pChild;
    }
    else if( pDescBranch2 == NULL)
    {
        pDescBranch2 = pChild;
    }
    else
    {
        this->Dump();
        cout << endl;
        YW_ASSERT_INFO(false, "SetChildBranch");
    }
}
bool GenealogicalNetworkNode :: IsAncestralTo(GenealogicalNetworkNode *pDescendent) const
{
    // allow multiple hops
    if( pDescendent == NULL )
    {
        return false;
    }
    GenealogicalNetworkNode *pthis=const_cast<GenealogicalNetworkNode*>(this);
    if( pDescendent == pthis)
    {
        return true;
    }
    bool fLeft = false;
    bool fRight = false;
    if( pDescBranch1 != NULL )
    {
        fLeft = pDescBranch1->GetDestNode()->IsAncestralTo(pDescendent);
    }
    if( fLeft == true )
    {
        return true;
    }
    if(pDescBranch2 != NULL)
    {
        fRight = pDescBranch2->GetDestNode()->IsAncestralTo(pDescendent);
    }
    return fRight;
}
void GenealogicalNetworkNode :: Dump() const
{
    cout << "NodeID[" << nodeId << "]:tid[";
    DumpTaxonId();
    cout << "]:mr[" << ratioMix << "]:";
    if( pDescBranch1!=NULL)
    {
        cout << "Destination node(left): " << pDescBranch1->GetDestNode()->GetID()<<"  ";
    }
    if( pDescBranch2!=NULL)
    {
        cout << "Destination node(right): " << pDescBranch2->GetDestNode()->GetID()<<"  ";
    }
    if( pSrcBranch1!=NULL)
    {
        cout << "Source node(left): " << pSrcBranch1->GetSrcNode()->GetID()<<"  ";
    }
    if( pSrcBranch2!=NULL)
    {
        cout << "Source node(right): " << pSrcBranch2->GetSrcNode()->GetID()<<"  ";
    }
    //cout << endl;
}
void GenealogicalNetworkNode :: DumpTaxonId() const
{
    // if user id string is set, use it; otherwise use the taxon id
    if( taxonStrUser.size() > 0 )
    {
        cout << taxonStrUser;
    }
    else
    {
        cout << taxonId;
    }
}
GenealogicalNetworkNode * GenealogicalNetworkNode :: GetLeftDescNode() const
{
    return GetLeftDesc()->GetDestNode();
}

GenealogicalNetworkNode * GenealogicalNetworkNode :: GetRightDescNode() const
{
    return GetRightDesc()->GetDestNode();
}


//***********************************************************************************
// Edge

GenealogicalNetworkBranch :: GenealogicalNetworkBranch( GenealogicalNetworkNode *pSrc, GenealogicalNetworkNode *pDest ): pNodeSrc(pSrc), pNodeDest(pDest), lenBranch(0.0)
{
}

double GenealogicalNetworkBranch :: GetLength() const
{
    return lenBranch;
}
void GenealogicalNetworkBranch :: SetLength(double len)
{
    lenBranch = len;
}

bool GenealogicalNetworkBranch :: IsMixing() const
{
    //  mixing if the dest node is mixing node
    return pNodeDest->IsMixNode();
}
bool GenealogicalNetworkBranch :: IsSrcMixing() const
{
    return pNodeSrc->IsMixNode();
}
bool GenealogicalNetworkBranch :: IsLeafBranch() const
{
    return pNodeDest->IsLeaf();
}
void GenealogicalNetworkBranch :: DetachFromSrc()
{
    GenealogicalNetworkNode *pSrc = GetSrcNode();
    GenealogicalNetworkNode *pDest = GetDestNode();
    pSrc->RemoveChild(pDest);
}
void GenealogicalNetworkBranch :: AttachToSrc(GenealogicalNetworkNode *pSrc, GenealogicalNetworkNode *pBrNodeeUnder)
{
    SetSrcNode(pSrc);
    SetDestNode(pBrNodeeUnder);
    pSrc->SetChildBranch(this);
    pBrNodeeUnder->SetParentBranch(this);
}
void GenealogicalNetworkBranch :: Dump() const
{
    //
    cout << "Br[" << GetLength() << "]: from node:";
    cout << endl;
    YW_ASSERT_INFO(pNodeSrc != NULL, "src: null");
    YW_ASSERT_INFO(pNodeDest!=NULL, "dest: null");
    pNodeSrc->Dump();
    cout << " to node: ";
    pNodeDest->Dump();
    cout << "    ";
}

bool GenealogicalNetworkBranch :: IsAncestralTo( GenealogicalNetworkBranch *pBrDescend ) const
{
    //
    GenealogicalNetworkNode *pNodeAnc = this->GetDestNode();
    GenealogicalNetworkNode *pNodeDesc = pBrDescend->GetSrcNode();
    return pNodeAnc->IsAncestralTo(pNodeDesc);
}

bool GenealogicalNetworkBranch :: IsAdjacentToOutgroup(int outgroup) const
{
    // is this branch next to outgroup (either descendent is or its )
    if(outgroup < 0)
    {
        return false;
    }
    int outgroupUse = outgroup-1;
    YW_ASSERT_INFO(outgroupUse>=0, "Fail");
    if( GetDestNode()->IsLeaf() && GetDestNode()->GetTaxonId()==outgroupUse )
    {
        return true;
    }
    GenealogicalNetworkNode *pOther = GetSrcNode()->GetOtherDescNode( GetDestNode() );
    if( pOther != NULL && pOther->IsLeaf() && pOther->GetTaxonId() ==outgroupUse)
    {
        return true;
    }
    return false;
}

//***********************************************************************************
// Marg-tree info

GenealogicalNetworkMTreeInfo :: GenealogicalNetworkMTreeInfo() : pMargTree(NULL), freq(0.0)
{
}

GenealogicalNetworkMTreeInfo :: GenealogicalNetworkMTreeInfo( MarginalTree *pMargTreeIn, double freqIn ) : pMargTree(pMargTreeIn), freq(freqIn)
{
}

GenealogicalNetworkMTreeInfo :: GenealogicalNetworkMTreeInfo(const GenealogicalNetworkMTreeInfo &rhs) : pMargTree(rhs.pMargTree), freq(rhs.freq)
{
}
GenealogicalNetworkMTreeInfo :: ~GenealogicalNetworkMTreeInfo()
{
}

bool GenealogicalNetworkMTreeInfo :: IsTopologicalEquiv(const GenealogicalNetworkMTreeInfo &other) const
{
    //
    return pMargTree->IsToplogicSame(*other.pMargTree);
}
void GenealogicalNetworkMTreeInfo :: CombineWith( const GenealogicalNetworkMTreeInfo &other )
{
    // assume the two are identical
    this->freq += other.freq;
}
void GenealogicalNetworkMTreeInfo :: FreeTree() const
{
    GenealogicalNetworkMTreeInfo *pthis=const_cast<GenealogicalNetworkMTreeInfo *>(this);
    if( pMargTree != NULL )
    {
        delete pthis->pMargTree;
        pthis->pMargTree = NULL;
    }
}

void GenealogicalNetworkMTreeInfo :: Dump() const
{
    // format: [freq] newick-format-tree
    cout << "[" << GetFreq() << "] ";
    string strNWTree = GetMargTree()->GetNewick() ;
    cout << strNWTree << endl;
}

//***********************************************************************************
// Marg-tree coding: how this tree is obtained from the network


GenealogicalNetworkMTreeCode :: GenealogicalNetworkMTreeCode( const vector<int> &ncode, const vector<GenealogicalNetworkNode *> &listMixNodesIn) : codeMTree(ncode), listMixNodes(listMixNodesIn)
{
}

GenealogicalNetworkMTreeCode:: GenealogicalNetworkMTreeCode(const GenealogicalNetworkMTreeCode &rhs) : codeMTree(rhs.codeMTree), listMixNodes(rhs.listMixNodes)
{
}

GenealogicalNetworkMTreeCode :: ~GenealogicalNetworkMTreeCode()
{
}

bool GenealogicalNetworkMTreeCode :: operator<(const GenealogicalNetworkMTreeCode &rhs) const
{
    return codeMTree < rhs.codeMTree;
}

void GenealogicalNetworkMTreeCode :: GetChosenBrs(set<GenealogicalNetworkBranch *> &setChosenBrs) const
{
    // given the choice, find the the list of branches chosen
    for(int i=0; i<(int)codeMTree.size(); ++i)
    {
        bool fLeft = IsLeftAtMixNode(i);
        GenealogicalNetworkBranch *pBrChosen;
        if( fLeft)
        {
            pBrChosen = listMixNodes[i]->GetAnces1();
        }
        else
        {
            pBrChosen = listMixNodes[i]->GetAnces2();
        }
        setChosenBrs.insert(pBrChosen);
    }
}

bool GenealogicalNetworkMTreeCode :: IsLeftAtMixNode(int indexMN) const
{
    YW_ASSERT_INFO(indexMN <(int)codeMTree.size(), "Overflow");
    int bpc = codeMTree[indexMN];
    if( bpc == 0 )
    {
        return true;
    }
    else
    {
        return false;
    }
}

void GenealogicalNetworkMTreeCode :: Dump() const
{
    cout << "Code: ";
    DumpIntVec( codeMTree );
}

GenealogicalNetworkMTreeCode & GenealogicalNetworkMTreeCode :: GetEmptyCode()
{
    //
    static vector<int> codeMTreeEmpty;
    static vector<GenealogicalNetworkNode *> listMixNodesEmpty;
    static GenealogicalNetworkMTreeCode instEmpty( codeMTreeEmpty, listMixNodesEmpty );
    return instEmpty;
}

//***************************************************************************
// Main interface for genealogical network (with admixture)

bool GenealogicalNetwork :: fNNIMode = false;


GenealogicalNetwork:: GenealogicalNetwork()
{
}

GenealogicalNetwork :: ~GenealogicalNetwork()
{
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it)
    {
        delete *it;
    }
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
    {
        delete *it;
    }
}

void GenealogicalNetwork :: SetNNIMode(bool f )
{
    fNNIMode = f;
}
bool GenealogicalNetwork :: IsNNIMode()
{
    return fNNIMode;
}

void GenealogicalNetwork :: InitWithTree(string &treeNW, int numTaxa)
{
    // initialize network with a single tree
    MarginalTree margTree;
    bool fTree = ReadinMarginalTreesNewickWLenString(treeNW, numTaxa, margTree);
    if(fTree == false)
    {
        cout << "Fail to construct the tree" << endl;
    }
    // add nodes first
    vector<GenealogicalNetworkNode *> listGNNodes;
    for(int i=0; i<margTree.GetTotNodesNum(); ++i)
    {
        GenealogicalNetworkNode *pnode = new GenealogicalNetworkNode;
        if( margTree.IsLeaf( i ) == true )
        {
            pnode->SetTaxonId( margTree.GetLabel(i) );
        }
        listGNNodes.push_back(pnode);
        this->AddNode(pnode);
    }
    for(int i=0; i<margTree.GetTotNodesNum(); ++i)
    {
        int ppos = margTree.GetParent(i);
        if( ppos < 0)
        {
            continue;
        }
        // add the edge
        double len = margTree.GetEdgeLen(i);
        this->AddBranch( listGNNodes[ppos], listGNNodes[i], len );
    }
}

void GenealogicalNetwork :: AddNode( GenealogicalNetworkNode *pNode )
{
    //
    setNodes.insert(pNode);
}

void GenealogicalNetwork :: AddBranch( GenealogicalNetworkNode *pSrcNode, GenealogicalNetworkNode *pDestNode, double len)
{
    YW_ASSERT_INFO(pSrcNode!=NULL, "AddBranch: src null");
    YW_ASSERT_INFO(pDestNode!=NULL, "AddBranch: dest null");
    //
    GenealogicalNetworkBranch *pBr = new GenealogicalNetworkBranch( pSrcNode, pDestNode );
    pBr->SetLength(len);
    pSrcNode->SetChildBranch(pBr);
    pDestNode->SetParentBranch(pBr);
    setBranches.insert(pBr);
}

void GenealogicalNetwork :: GetAllBranches( set<GenealogicalNetworkBranch *> &setAllBranches ) const
{
    //
    setAllBranches = this->setBranches;
}

void GenealogicalNetwork :: RetriveAllMarginalTrees( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> &mapMargTreesWithFreq ) const
{
    // retrive all maginal trees (w/ their proper coding); note: marg trees are dynamic allocated
    // and need to be freed up
    vector<GenealogicalNetworkNode *> listMixNodes ;
    GetMixNodes( listMixNodes );
    
    // all code
    set<GenealogicalNetworkMTreeCode > setMTCodes;
    GetMTCodesForMixNodes( listMixNodes, setMTCodes );
#if 0
cout << "RetriveAllMarginalTrees: number of codes: " << setMTCodes.size() << "\n";
for(set<GenealogicalNetworkMTreeCode> :: iterator it = setMTCodes.begin(); it != setMTCodes.end(); ++it)
{
it->Dump();
}
#endif
    
    // ret. marg tree for each code
    if( setMTCodes.size() > 0 )
    {
        for( set<GenealogicalNetworkMTreeCode > :: iterator it = setMTCodes.begin(); it != setMTCodes.end(); ++it )
        {
            //
            MarginalTree *pMTCur = new MarginalTree;
            RetriveMargTreeForCode( *it, *pMTCur );
            double freq = GetMargTreeFreqForCode(*it);
            GenealogicalNetworkMTreeInfo mtInfo( pMTCur, freq );
            mapMargTreesWithFreq.insert( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: value_type( *it, mtInfo ) );
        }
    }
    else
    {
        // if there are no network node, then just return the single tree
        GenealogicalNetworkMTreeCode codeEmpty( GenealogicalNetworkMTreeCode :: GetEmptyCode() );
        MarginalTree *pMTCur = new MarginalTree;
        RetriveMargTreeForCode( codeEmpty, *pMTCur );
        double freq = 1.0;
        GenealogicalNetworkMTreeInfo mtInfo( pMTCur, freq );
        mapMargTreesWithFreq.insert( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: value_type( codeEmpty, mtInfo ) );
    }
}

void GenealogicalNetwork :: RetriveAllSubMarginalTrees(int szSubsetTaxa, map<set<int>, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> > &mapSubMargTreesWithFreq ) const
{
//cout << "RetriveAllSubMarginalTrees: subset size: " << szSubsetTaxa << endl;
    // enumerate all subset of taxa
    set<int> setTaxaAll;
    GetAllTaxa(setTaxaAll);
    vector<int> posvec;
    YW_ASSERT_INFO( szSubsetTaxa <= (int)setTaxaAll.size(), "Subset size: too large" );
    
    // get all complete marg trees
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapCompleteMargTreesWithFreq;
    RetriveAllMarginalTrees( mapCompleteMargTreesWithFreq );
    
    GetFirstCombo( szSubsetTaxa, (int)setTaxaAll.size(), posvec );
    while (true)
    {
        set<int> posvecss;
        PopulateSetByVec(posvecss, posvec);
        map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapSubMargTreesWithFreqStep;
        RetriveSubMarginalTreesFromCompleteTrees(posvecss, mapCompleteMargTreesWithFreq, mapSubMargTreesWithFreqStep);
        mapSubMargTreesWithFreq.insert( map<set<int>, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> > :: value_type( posvecss, mapSubMargTreesWithFreqStep ) );
#if 0
cout << "** Subtrees for subset: ";
DumpIntSet(posvecss);
for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapSubMargTreesWithFreqStep.begin(); it != mapSubMargTreesWithFreqStep.end(); ++it )
{
it->second.Dump();
}
#endif
        if( GetNextCombo( szSubsetTaxa, (int)setTaxaAll.size(), posvec ) ==false)
        {
            break;
        }
    }
    // free
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapCompleteMargTreesWithFreq.begin(); it != mapCompleteMargTreesWithFreq.end(); ++it )
    {
        it->second.FreeTree();
    }
}

void GenealogicalNetwork :: RetriveSubMarginalTreesFromCompleteTrees(const set<int> &taxaSet, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> &mapCompleteMargTreesWithFreq, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> &mapSubMargTreesWithFreq ) const
{
    // retrieve subtrees from the given complete trees; will combine trees if there are equivalent trees
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapCompleteMargTreesWithFreq.begin(); it != mapCompleteMargTreesWithFreq.end(); ++it )
    {
        // obtain the subtree
        MarginalTree *pSubtree = new MarginalTree;
        map<int,int> mapTaxaTemp;
        CreateSubtreeFromLeaves(*(it->second.GetMargTree()), taxaSet, *pSubtree, mapTaxaTemp);
        GenealogicalNetworkMTreeInfo subtreeInfo( pSubtree, it->second.GetFreq() );
        
        // is this new?
        bool fNew = true;
        for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo>  :: iterator it2= mapSubMargTreesWithFreq.begin(); it2 != mapSubMargTreesWithFreq.end(); ++it2 )
        {
            if( it2->second.IsTopologicalEquiv(subtreeInfo) == true )
            {
                it2->second.CombineWith( subtreeInfo );
                fNew = false;
                delete pSubtree;
                break;;
            }
        }
        if( fNew == true )
        {
            mapSubMargTreesWithFreq.insert( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: value_type( it->first, subtreeInfo ) );
        }
    }
}

void GenealogicalNetwork :: GetWtsForAllMargTrees(vector<double> &listWts) const
{
    //
    listWts.clear();
    // retrive all maginal trees (w/ their proper coding); note: marg trees are dynamic allocated
    // and need to be freed up
    vector<GenealogicalNetworkNode *> listMixNodes ;
    GetMixNodes( listMixNodes );
    
    // all code
    set<GenealogicalNetworkMTreeCode > setMTCodes;
    GetMTCodesForMixNodes( listMixNodes, setMTCodes );
    
    // ret. marg tree for each code
    for( set<GenealogicalNetworkMTreeCode > :: iterator it = setMTCodes.begin(); it != setMTCodes.end(); ++it )
    {
        //
        double freq = GetMargTreeFreqForCode(*it);
        listWts.push_back(freq);
    }

}

void GenealogicalNetwork :: RetriveAllNetCode( set<GenealogicalNetworkMTreeCode > &setMTCodes ) const
{
    // retrive all maginal trees (w/ their proper coding); note: marg trees are dynamic allocated
    // and need to be freed up
    vector<GenealogicalNetworkNode *> listMixNodes ;
    GetMixNodes( listMixNodes );
    
    // all code
    GetMTCodesForMixNodes( listMixNodes, setMTCodes );
}

void GenealogicalNetwork :: RetriveNgbrNetsOneEvt( vector<GenealogicalNetwork *> &listNgbrNetsDist1, int outgroup ) const
{
    //
    set<GenealogicalNetworkBranch *> setAllBranches;
    GetAllBranches( setAllBranches);
    for( set<GenealogicalNetworkBranch *>:: iterator it = setAllBranches.begin(); it != setAllBranches.end(); ++it )
    {
        if( (*it)->IsAdjacentToOutgroup(outgroup) == false )
        {
            RetriveNgbrNetsOneEvtForEdge(*it, listNgbrNetsDist1);
        }
    }
//cout << "TOTAL NUMBER OF NEIGHBORING NETWORKS: " << listNgbrNetsDist1.size() << endl;
}

void GenealogicalNetwork :: RetriveNgbrNetsOneNewMix( vector<GenealogicalNetwork *> &listNetsOneNewMix ) const
{
    // first the destination branch
    set<GenealogicalNetworkBranch *> setAllBranches;
    GetAllBranches( setAllBranches);
    
    for( set<GenealogicalNetworkBranch *>:: iterator it = setAllBranches.begin(); it != setAllBranches.end(); ++it )
    {
        RetriveNgbrNetsOneNewMixForEdge(*it, listNetsOneNewMix);
    }
}


void GenealogicalNetwork :: RemoveTrivialCycles()
{
    // remove simple cycles of a network that has a single node for both sources at a network node
    while(true)
    {
        bool fCont = false;
        //
        vector<GenealogicalNetworkNode *> listMixNodes;
        GetMixNodes( listMixNodes );
        for( int i=0; i<(int)listMixNodes.size(); ++i  )
        {
            //
            if( listMixNodes[i]->GetAnces1()->GetSrcNode() == listMixNodes[i]->GetAnces2()->GetSrcNode() )
            {
                // this is a node to remove since it has duplicate parents
                GenealogicalNetworkNode *pAncOfTwo = listMixNodes[i]->GetAnces1()->GetSrcNode();
                YW_ASSERT_INFO( pAncOfTwo != NULL, "Cannot be null1");
                YW_ASSERT_INFO(pAncOfTwo->IsMixNode() == false, "Fatal error: this node cannot be mixing node");
                GenealogicalNetworkNode *pAncOfTwoPar = pAncOfTwo->GetParentSingle();
                
#if 0
                if( pAncOfTwoPar == NULL )
                {
                    cout << "In RemoveTrivialCycles: current network is: \n";
                    Dump();
                    OutputGML("tmp.debug.gml");
                    cout << "Processing mixing node: ";
                    listMixNodes[i]->Dump();
                    cout << endl;
                }
#endif
                
                
//#if 0
                //YW_ASSERT_INFO(pAncOfTwoPar != NULL, "Cannot be null");
                // pAncofTwo must be root; then take this into consideration
                GenealogicalNetworkNode *pDescOfTwo = listMixNodes[i]->GetChildSingle();
                double len1 = GetBranch(pAncOfTwo, listMixNodes[i])->GetLength();
                RemoveBranch( pAncOfTwo, listMixNodes[i], true );
                double len2 = GetBranch( pAncOfTwo, listMixNodes[i] )->GetLength();
                RemoveBranch( pAncOfTwo, listMixNodes[i], true );
                double len4 = GetBranch(listMixNodes[i], pDescOfTwo)->GetLength();
                double lenNew = 0.5*(len1+len2)+len4;
                pDescOfTwo->RemoveParent( listMixNodes[i] );
                RemoveBranch( listMixNodes[i], pDescOfTwo, true );
                RemoveNode( listMixNodes[i], false );
                RemoveNode( pAncOfTwo, false );
                //GenealogicalNetworkNode *pNodeParNew = pAncOfTwo;
                if( pAncOfTwoPar != NULL )
                {
                    pAncOfTwoPar->RemoveChild(pAncOfTwo);
                    double len3 = GetBranch(pAncOfTwoPar, pAncOfTwo)->GetLength();
                    lenNew += len3;
                    RemoveBranch( pAncOfTwoPar, pAncOfTwo, true );
                    //pNodeParNew = pAncOfTwoPar;
                    // finally add the remaining link
                    AddBranch( pAncOfTwoPar, pDescOfTwo, lenNew );
                }

//#endif
                
#if 0
                if( pAncOfTwoPar != NULL )
                {
                    GenealogicalNetworkNode *pDescOfTwo = listMixNodes[i]->GetChildSingle();
                    double len1 = GetBranch(pAncOfTwo, listMixNodes[i])->GetLength();
                    YW_ASSERT_INFO(pAncOfTwoPar != NULL, "Cannot be null");
                    pAncOfTwoPar->RemoveChild(pAncOfTwo);
                    RemoveBranch( pAncOfTwo, listMixNodes[i], true );
                    double len2 = GetBranch( pAncOfTwo, listMixNodes[i] )->GetLength();
                    RemoveBranch( pAncOfTwo, listMixNodes[i], true );
                    double len3 = GetBranch(pAncOfTwoPar, pAncOfTwo)->GetLength();
                    RemoveBranch( pAncOfTwoPar, pAncOfTwo, true );
                    double len4 = GetBranch(listMixNodes[i], pDescOfTwo)->GetLength();
                    double lenNew = 0.5*(len1+len2)+len3+len4;
                    pDescOfTwo->RemoveParent( listMixNodes[i] );
                    RemoveBranch( listMixNodes[i], pDescOfTwo, true );
                    RemoveNode( listMixNodes[i], false );
                    RemoveNode( pAncOfTwo, false );
                    AddBranch( pAncOfTwoPar, pDescOfTwo, lenNew );
                }
//#if 0
                else
                {
                    // pAncofTwo must be root; then take this into consideration
                    // here we simply remove the root as well
cout << "before start, pAncOfTwo: ";
pAncOfTwo->Dump();
cout << endl;
                    pAncOfTwo->RemoveChild(listMixNodes[i]);
                    pAncOfTwo->RemoveChild(listMixNodes[i]);
                    GenealogicalNetworkNode *pDescOfTwo = listMixNodes[i]->GetChildSingle();
                    listMixNodes[i]->RemoveChild(pDescOfTwo);
                    listMixNodes[i]->RemoveParent(pAncOfTwo);
                    double len1 = GetBranch(pAncOfTwo, listMixNodes[i])->GetLength();
cout << "len1: " << len1 << endl;
                    RemoveBranch( pAncOfTwo, listMixNodes[i], true );

cout << "(1), pAncOfTwo: ";
pAncOfTwo->Dump();
cout << endl;
cout << "remove branch1\n";
                    double len2 = GetBranch( pAncOfTwo, listMixNodes[i] )->GetLength();
cout << "len2: " << len2 << endl;
                    RemoveBranch( pAncOfTwo, listMixNodes[i], true );
                    //pAncOfTwo->RemoveChild(listMixNodes[i]);
                    
cout << "(2) pAncOfTwo: ";
pAncOfTwo->Dump();
cout << endl;
cout << "remove branch2\n";
                    double len4 = GetBranch(listMixNodes[i], pDescOfTwo)->GetLength();
cout << "len4:" << len4 << endl;
                    double lenNew = 0.5*(len1+len2)+len4;
                    pDescOfTwo->RemoveParent( listMixNodes[i] );
cout << "remove parent for descoftwo\n";
                    RemoveBranch( listMixNodes[i], pDescOfTwo, true );
cout << "remove branch between mix and child\n";
                    RemoveNode( listMixNodes[i], false );
cout << "remove mix node\n";
                    YW_ASSERT_INFO(pAncOfTwo!=NULL, "pAncofTwo: NULL");
                    //YW_ASSERT_INFO(pDescOfTwo!=NULL, "pDescOfTwo: NULL");
                    RemoveNode( pAncOfTwo, false );
cout << "pAncOfTwo: ";
pAncOfTwo->Dump();
cout << endl;
cout << "pDescOfTwo:";
pDescOfTwo->Dump();
cout << endl;
//cout << "Before adding new branch: network \n";
//OutputGML("tmp.endofcycleremoval.debug2.gml");
                    //AddBranch( pAncOfTwo, pDescOfTwo, lenNew );
cout << "After cycle removing: network \n";
OutputGML("tmp.endofcycleremoval.debug.gml");
                }
//#endif
#endif
                
                fCont = true;
                break;
            }
        }
        
        if(fCont == false)
        {
            break;
        }
    }
//cout << "After cycle removing: network \n";
//OutputGML("tmp.endofcycleremoval.debug.gml");
}

void GenealogicalNetwork :: Dump() const
{
    //
    cout << "[#nodes; " << setNodes.size() << "], [#edges:" << setBranches.size() << "]\n";
    cout << "--list of nodes: ";
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it)
    {
        (*it)->Dump();
        cout << endl;
    }
    cout << "--list of edges: ";
    for(set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
    {
        (*it)->Dump();
        cout << endl;
    }
}

void GenealogicalNetwork :: GetMixNodes( vector<GenealogicalNetworkNode *> &listMixNodes ) const
{
    //
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it)
    {
        if( (*it)->IsMixNode() )
        {
            listMixNodes.push_back(*it);
        }
    }
}

void GenealogicalNetwork :: GetLeaves( vector<GenealogicalNetworkNode *> &listLeaves ) const
{
    //
    listLeaves.clear();
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it)
    {
        if( (*it)->IsLeaf() )
        {
            listLeaves.push_back(*it);
        }
    }
}

void GenealogicalNetwork :: GetMTCodesForMixNodes( const vector<GenealogicalNetworkNode *> &listMixNodes, set<GenealogicalNetworkMTreeCode > &setMTCodes ) const
{
#if 0
cout << "GetMTCodesForMixNodes: list of mix nodes: \n";
for(int i=0; i<(int)listMixNodes.size(); ++i)
{
listMixNodes[i]->Dump();
}
#endif
    
    //
    int numMN = listMixNodes.size();
    vector<int> listChoices;
    GetFirstMutliChoice( numMN, 2, listChoices );
    while(true)
    {
#if 0
cout << "listChoices: ";
DumpIntVec(listChoices);
#endif
        GenealogicalNetworkMTreeCode ncode( listChoices, listMixNodes );
        setMTCodes.insert(ncode);
#if 0
cout << "Code constructed: ";
ncode.Dump();
#endif
        
        if( GetNextMutliChoice( numMN, 2, listChoices ) == false )
        {
            break;
        }
    }
}

void GenealogicalNetwork :: RetriveMargTreeForCode( const GenealogicalNetworkMTreeCode &ncode, MarginalTree &margTree ) const
{
#if 0
cout << "RetriveMargTreeForCode: nocdoe: ";
ncode.Dump();
#endif
    //
    set<GenealogicalNetworkBranch *> setChosenBrs;
    ncode.GetChosenBrs(setChosenBrs);
    stack<int> stackParPos;
    map<int,int> mapParPos;
    map<int, double> mapBrLen;
    // init the
    int numTaxa = GetNumLeaves();
    int posToUseNext = numTaxa;
    RecSearchForClusters( setChosenBrs, GetRoot(), posToUseNext, stackParPos, mapParPos, mapBrLen );
#if 0
cout << "numTaxa: " << numTaxa << ", posToUseNext: " << posToUseNext << ", size of stack: " << stackParPos.size() << ", mapParPos: ";
for(map<int,int> :: iterator it = mapParPos.begin(); it != mapParPos.end(); ++it)
{
cout << "[" << it->first << "," << it->second << "]  ";
}
cout << "mapBrLen: ";
for(map<int,double> :: iterator it = mapBrLen.begin(); it != mapBrLen.end(); ++it)
{
cout << "[" << it->first << "," << it->second << "]  ";
}
#endif
    // create marg tree from the map
    vector<int> vecLabels;
    vector<int> vecpp;
    vector<double> vecBrLen;
    for( int i=0; i<2*numTaxa-1; ++i )
    {
        if( i<numTaxa)
        {
            vecLabels.push_back(i);
        }
        else
        {
            vecLabels.push_back(-1);
        }
        
        int ppos = -1;
        if( mapParPos.find(i) != mapParPos.end() )
        {
            ppos = mapParPos[i];
        }
        if( i >=numTaxa && i <2*numTaxa-2)
        {
//GenealogicalNetwork *pthis=const_cast<GenealogicalNetwork*>(this);
//            pthis->OutputGML("debug.gml");

if( ppos < 0 )
{
cout << "ppos: " << ppos << ", i=" << i << endl;
this->Dump();
GenealogicalNetwork *pthis=const_cast<GenealogicalNetwork*>(this);
pthis->OutputGML("debug.gml");
}
            YW_ASSERT_INFO(ppos >=0, "Wrong2" );
        }
        vecpp.push_back(ppos);
        double brLen = 0.0;
        if( mapBrLen.find(i) != mapBrLen.end() )
        {
            brLen = mapBrLen[i];
        }
        vecBrLen.push_back(brLen);
    }
#if 0
cout << "vecLabels: ";
DumpIntVec(vecLabels);
cout << "vecpp: ";
DumpIntVec(vecpp);
cout << "vecBrLen: ";
DumpDoubleVec(vecBrLen);
#endif
    margTree.SetNumLeaves(numTaxa);
    margTree.SetLabelList(vecLabels);
    margTree.SetParList(vecpp);
    margTree.SetBranchLenList( vecBrLen );
    margTree.BuildDescendantInfo();
    margTree.SortByLeafId();
}

double GenealogicalNetwork :: GetMargTreeFreqForCode( const GenealogicalNetworkMTreeCode &ncode ) const
{
    //
    double res = 1.0;
    vector<int> codeChoices = ncode.GetCode();
    vector<GenealogicalNetworkNode *> listMixNodes = ncode.GetMixNodes();
    for(int i=0; i<(int)codeChoices.size(); ++i)
    {
        int bitstep = codeChoices[i];
        double freqNode = listMixNodes[i]->GetMixRatio();
        double resstep = freqNode;
        if( bitstep == 1 )
        {
            resstep = 1.0-freqNode;
        }
//cout << "i = " << i << ": bitstep" << bitstep << ", freqNode: " << freqNode << ", resstep: " << resstep << endl;
        res *= resstep;
    }
//cout << "---Freq for code: " << res << endl;
    return res;
}

bool GenealogicalNetwork :: IsBranchIn( GenealogicalNetworkBranch *pBr, const set<GenealogicalNetworkBranch *> &setBrs ) const
{
    //
    bool res = false;
    for(set<GenealogicalNetworkBranch *> :: const_iterator it = setBrs.begin(); it != setBrs.end(); ++it)
    {
        const GenealogicalNetworkBranch *pBrStep = *it;
        if( pBr->GetSrcNode()==pBrStep->GetSrcNode()  && pBr->GetDestNode()==pBrStep->GetDestNode() )
        {
            res = true;
            break;
        }
    }
    return res;
}

bool GenealogicalNetwork :: RecSearchForClusters( const set<GenealogicalNetworkBranch *> &setChosenBrs, GenealogicalNetworkNode *pnCurr, int &posToUseNext, stack< int > &stackParPos, map<int,int> &mapParPos, map<int, double> &mapBrLen ) const
{
    if( pnCurr == NULL)
    {
        // nothing to pursue
        return false;
    }
#if 0
cout << "RecSearchForClusters: posToUseNext: " << posToUseNext << ", pnCurr: ";
pnCurr->Dump();
cout << "Number of chosen edges: " << setChosenBrs.size() << endl;
#endif
    // for given choice at network nodes, find the list of parent/child position info (as
    // required by MarginalTree class) and also branch length of each cluster
    // pnCurr: where in the network to look for clusters
    double brLen = 0.0;
    GenealogicalNetworkBranch *pAncBr = GetSelAncBrFrom( pnCurr, setChosenBrs );
    if( pAncBr != NULL )
    {
        brLen = pAncBr->GetLength();
    }
    // top-down from pnCurr node by following the branches as given (when there is choice)
    // remember the parent position and branch length traversed
    // ASSUME: leaf already recorded (taxon: id from 1 to n)
    // return true if there are clades found below; false otherwise (no calde below)
    if( pnCurr->IsLeaf() == true )
    {
        int tid = pnCurr->GetTaxonId();
        // position is tid-1 for leaf by default
        int tpos = GetLeafPosById( tid );
//cout << "Leaf: tid = " << tid << ", tpos: " << tpos << endl;
        //mapParPos.insert( map<int,int> :: value_type(tpos, posToUseNext) );
        stackParPos.push( tpos );
        mapBrLen.insert( map<int,double> :: value_type( tpos, brLen )  );
        return true;
    }
    
    // now deal with two descendents; recursively search
    if( pnCurr->IsMixNode() == false )
    {
//cout << "Is not a mixing node: \n";
        // make sure this is selected
        GenealogicalNetworkNode *pnChildLeft = pnCurr->GetLeftDescNode();
        GenealogicalNetworkBranch *pBrChildLeft = GetBranch( pnCurr, pnChildLeft );
        //if( pBrChildLeft->IsMixing() && setChosenBrs.find(pBrChildLeft) == setChosenBrs.end() )
        if( pBrChildLeft->IsMixing() && IsBranchIn( pBrChildLeft, setChosenBrs ) ==false )
        {
            pnChildLeft = NULL;
        }
        GenealogicalNetworkNode *pnChildRight = pnCurr->GetRightDescNode();
        GenealogicalNetworkBranch *pBrChildRight = GetBranch( pnCurr, pnChildRight );
        if( pBrChildRight->IsMixing() && IsBranchIn(pBrChildRight, setChosenBrs) == false )
        //if( pBrChildRight->IsMixing() && setChosenBrs.find(pBrChildRight) == setChosenBrs.end() )
        {
            pnChildRight = NULL;
        }
        
        bool fLeft = RecSearchForClusters( setChosenBrs, pnChildLeft, posToUseNext, stackParPos, mapParPos, mapBrLen );
        bool fRight = RecSearchForClusters( setChosenBrs, pnChildRight, posToUseNext, stackParPos, mapParPos, mapBrLen );
        GenealogicalNetworkBranch *pAncBr = GetSelAncBrFrom( pnCurr, setChosenBrs );

        // if both true (find a cluster), create a new intrnal node
        if( fLeft && fRight)
        {
            int posIntNode = posToUseNext++;
            int posChildLeft = stackParPos.top();
            stackParPos.pop();
            int posChildRight = stackParPos.top();
            stackParPos.pop();
            mapParPos.insert( map<int,int> :: value_type(posChildLeft, posIntNode) );
            mapParPos.insert( map<int,int> :: value_type(posChildRight, posIntNode) );
            stackParPos.push( posIntNode );
            mapBrLen.insert( map<int,double> :: value_type( posIntNode, brLen )  );
        }
        else if(fLeft || fRight)
        {
            int posDescSingle = stackParPos.top();
            YW_ASSERT_INFO(mapBrLen.find(posDescSingle) != mapBrLen.end(), "Fail to find");
            mapBrLen[posDescSingle] += brLen;
        }
        
        return fLeft || fRight;
    }
    else
    {
//cout << "Is mixing node.\n";
        // here assume mixing node has only one child
        // before continuing: need to check to ensure this branch is actually chosen
        GenealogicalNetworkNode *pnChildDesc = pnCurr->GetChildSingle();
        GenealogicalNetworkBranch *pBrChildDesc = GetBranch( pnCurr, pnChildDesc );
        YW_ASSERT_INFO(pBrChildDesc != NULL, "Branch is not found");
        if( pBrChildDesc->IsMixing() && setChosenBrs.find(pBrChildDesc) == setChosenBrs.end() )
        {
            pnChildDesc = NULL;
        }
        
        bool fDesc = RecSearchForClusters( setChosenBrs, pnChildDesc, posToUseNext, stackParPos, mapParPos, mapBrLen );
        if( fDesc )
        {
            int posDescSingle = stackParPos.top();
            YW_ASSERT_INFO(mapBrLen.find(posDescSingle) != mapBrLen.end(), "Fail to find");
            mapBrLen[posDescSingle] += brLen;
        }
        return fDesc;
    }
}

GenealogicalNetworkBranch * GenealogicalNetwork :: GetSelAncBrFrom( GenealogicalNetworkNode *pnCurr, const set<GenealogicalNetworkBranch *> &setChosenBrs ) const
{
    //
    if(pnCurr->IsMixNode() == false )
    {
        GenealogicalNetworkBranch *pBrAncSel = pnCurr->GetParentBrSingle();
        return pBrAncSel;
    }
    else
    {
        //
        GenealogicalNetworkBranch* pBrAnc1 = pnCurr->GetAnces1();
        GenealogicalNetworkBranch *pBrAnc2 = pnCurr->GetAnces2();
        if( setChosenBrs.find(pBrAnc1) != setChosenBrs.end() )
        {
            return pBrAnc1;
        }
        else if( setChosenBrs.find(pBrAnc2) != setChosenBrs.end() )
        {
            //
            return pBrAnc2;
        }
        else
        {
            YW_ASSERT_INFO(false, "Wrong: no choices can be made");
            return NULL;
        }
    }
}

void GenealogicalNetwork :: GetChangedMargTreeCodesByBrLen( GenealogicalNetworkBranch *pBranchChanged, set<GenealogicalNetworkMTreeCode> &setChangedMargTreeCodes )
{
    // retrive all maginal trees (w/ their proper coding)
    vector<GenealogicalNetworkNode *> listMixNodes ;
    GetMixNodes( listMixNodes );
    GetMTCodesForMixNodes( listMixNodes, setChangedMargTreeCodes );
    
    // if this branch is not mixing, then need to get all the marg trees
    if( pBranchChanged->IsMixing() == true)
    {
        //
        GenealogicalNetworkNode *pnMix = pBranchChanged->GetDestNode();
        int posNode = GetItemIndexInVecGen( listMixNodes, pnMix );
        YW_ASSERT_INFO(posNode >= 0, "Wrong");
        bool fLeft = pnMix->IsLeftAncesBranch(pBranchChanged);
        
        set<GenealogicalNetworkMTreeCode> setCodesNew;
        for( set<GenealogicalNetworkMTreeCode> :: iterator it = setChangedMargTreeCodes.begin(); it != setChangedMargTreeCodes.end(); ++it)
        {
            bool fNodeLeft = it->IsLeftAtMixNode( posNode );
            if( (fLeft^fNodeLeft) == false )
            {
                setCodesNew.insert(*it);
            }
        }
        setChangedMargTreeCodes = setCodesNew;
    }
}


int GenealogicalNetwork :: GetNumLeaves() const
{
    //
    vector<GenealogicalNetworkNode *> listLeaves;
    GetLeaves(listLeaves);
    return listLeaves.size();
}

GenealogicalNetworkNode * GenealogicalNetwork :: GetRoot() const
{
    //
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it)
    {
        if( (*it)->GetNumParents() == 0 )
        {
            return *it;
        }
    }
    YW_ASSERT_INFO(false, "Fail to find the root");
    return NULL;
}

GenealogicalNetworkNode * GenealogicalNetwork :: GetLeafWithTaxon(int taxon) const
{
    //
    vector<GenealogicalNetworkNode *> listLeaves;
    GetLeaves(listLeaves);
    for(int i=0; i<(int)listLeaves.size(); ++i)
    {
        if( listLeaves[i]->GetTaxonId() == taxon )
        {
            return listLeaves[i];
        }
    }
    return NULL;
}


void GenealogicalNetwork :: UpdateMargTreesForChangedBrLen(GenealogicalNetworkBranch *pBrToChange, double brLenNew, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> &mapMargTreesWithFreq)
{
    // create the list of marginal trees after updating one branch length
    pBrToChange->SetLength(brLenNew);
    set<GenealogicalNetworkMTreeCode> setChangedMTCodes;
    GetChangedMargTreeCodesByBrLen(pBrToChange, setChangedMTCodes);
    for( set<GenealogicalNetworkMTreeCode>::iterator it= setChangedMTCodes.begin(); it != setChangedMTCodes.end(); ++it )
    {
        //
        YW_ASSERT_INFO( mapMargTreesWithFreq.find(*it)!=mapMargTreesWithFreq.end(), "Fail to find" );
        RetriveMargTreeForCode( *it, *mapMargTreesWithFreq[*it].GetMargTree() );
    }
}

void GenealogicalNetwork :: RetriveAffectedMargTreesForChangedBr(GenealogicalNetworkBranch *pBrToChange, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> &mapMargTreesWithFreq)
{
    //
    set<GenealogicalNetworkMTreeCode> setChangedMTCodes;
    GetChangedMargTreeCodesByBrLen(pBrToChange, setChangedMTCodes);
    for( set<GenealogicalNetworkMTreeCode>::iterator it= setChangedMTCodes.begin(); it != setChangedMTCodes.end(); ++it )
    {
        //
        MarginalTree *pMTCur = new MarginalTree;
        RetriveMargTreeForCode( *it, *pMTCur );
        double freq = GetMargTreeFreqForCode(*it);
        GenealogicalNetworkMTreeInfo mtInfo( pMTCur, freq );
        mapMargTreesWithFreq.insert( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: value_type( *it, mtInfo ) );
    }

}

GenealogicalNetworkBranch * GenealogicalNetwork :: GetBranch( GenealogicalNetworkNode *pSrc, GenealogicalNetworkNode *pDest ) const
{
    //
    GenealogicalNetworkBranch *pres = NULL;
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
    {
        if( (*it)->GetSrcNode() == pSrc && (*it)->GetDestNode() == pDest )
        {
            pres = *it;
            break;
        }
    }
    return pres;
}

void GenealogicalNetwork :: RetriveNgbrNetsOneEvtForEdge( GenealogicalNetworkBranch *pBranchToChange, vector<GenealogicalNetwork *> &listNgbrNetsDist1 ) const
{
    if(pBranchToChange->IsSrcMixing() )
    {
        RetriveNgbrNetsOneEvtForMixEdge(pBranchToChange, listNgbrNetsDist1);
        return;
    }
    
    // change where the branch attaches to and return all the possible networks
    set<GenealogicalNetworkBranch *> setBrsToReattach;
    FindReattachBranches( pBranchToChange, setBrsToReattach, IsNNIMode() );
#if 0
cout << "vvvvvvvvvvvvvvvvvvvvvvvvvvvvRetriveNgbrNetsOneEvtForEdge: pBranchToCHange: ";
pBranchToChange->Dump();
cout << "  Branches to attach: ";
for(set<GenealogicalNetworkBranch *>::iterator it= setBrsToReattach.begin(); it != setBrsToReattach.end(); ++it)
{
(*it)->Dump();
}
cout << "^^^^Number of attaching edges: " << setBrsToReattach.size() << endl;
#endif
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBrsToReattach.begin(); it != setBrsToReattach.end(); ++it )
    {
#if 0
cout << "Now reattach to this branch: ";
(*it)->Dump();
#endif
        map<GenealogicalNetworkNode *, GenealogicalNetworkNode*> mapOldNodeToNew;
        GenealogicalNetwork *pNetCopy = Copy( &mapOldNodeToNew );
#if 0
cout << "Network copy: ";
pNetCopy->Dump();
#endif
        //
        GenealogicalNetworkNode *pnodeDest = pBranchToChange->GetDestNode();
        GenealogicalNetworkNode *pnodeSrc = pBranchToChange->GetSrcNode();
        YW_ASSERT_INFO(mapOldNodeToNew.find(pnodeDest) != mapOldNodeToNew.end(), "Fail to find1");
        YW_ASSERT_INFO(mapOldNodeToNew.find(pnodeSrc) != mapOldNodeToNew.end(), "Fail to find2");
        GenealogicalNetworkNode *pnodeSrcCopy = mapOldNodeToNew[pnodeSrc];
        GenealogicalNetworkNode *pnodeDestCopy = mapOldNodeToNew[pnodeDest];
        GenealogicalNetworkBranch *pBrSrc = pNetCopy->GetBranch( pnodeSrcCopy,  pnodeDestCopy);
        YW_ASSERT_INFO(mapOldNodeToNew.find((*it)->GetSrcNode() ) != mapOldNodeToNew.end(), "Fail to find3");
        YW_ASSERT_INFO(mapOldNodeToNew.find((*it)->GetDestNode() ) != mapOldNodeToNew.end(), "Fail to find4");
        GenealogicalNetworkBranch *pBrDestCopy = pNetCopy->GetBranch( mapOldNodeToNew[(*it)->GetSrcNode()],  mapOldNodeToNew[(*it)->GetDestNode()]);
        YW_ASSERT_INFO(pBrDestCopy != NULL, "Fail to find5");
        pNetCopy->ReattachBranchTo( pBrSrc, pBrDestCopy );
        
        // ensure the network is OK
        pNetCopy->RemoveTrivialCycles();
        
#if 0
cout << "*****************Constructed one neighbor network: ";
pNetCopy->Dump();
#endif
        listNgbrNetsDist1.push_back(pNetCopy);
    }
    // YW: this does not seem to work well (01/29/16); SkIP for now
//#if 0
    // finally also allow the branch to attach as sibling of the root (unless it is already incident to the root)
    // as before, don't allow mising edge to attach to root sib
    if( pBranchToChange->GetSrcNode()->IsRoot() == false  && pBranchToChange->IsSrcMixing() == false  )
    {
        //
        map<GenealogicalNetworkNode *, GenealogicalNetworkNode*> mapOldNodeToNew;
        GenealogicalNetwork *pNetCopy = Copy( &mapOldNodeToNew );
#if 0
        cout << "Network copy: ";
        pNetCopy->Dump();
#endif
        //
        GenealogicalNetworkNode *pnodeDest = pBranchToChange->GetDestNode();
        GenealogicalNetworkNode *pnodeSrc = pBranchToChange->GetSrcNode();
        YW_ASSERT_INFO(mapOldNodeToNew.find(pnodeDest) != mapOldNodeToNew.end(), "Fail to find1");
        YW_ASSERT_INFO(mapOldNodeToNew.find(pnodeSrc) != mapOldNodeToNew.end(), "Fail to find2");
        GenealogicalNetworkNode *pnodeSrcCopy = mapOldNodeToNew[pnodeSrc];
        GenealogicalNetworkNode *pnodeDestCopy = mapOldNodeToNew[pnodeDest];
        GenealogicalNetworkBranch *pBrSrc = pNetCopy->GetBranch( pnodeSrcCopy,  pnodeDestCopy);
        pNetCopy->ReattachBranchAsRootSib( pBrSrc );
        
        // ensure the network is OK
        pNetCopy->RemoveTrivialCycles();
        
#if 0
        cout << "*****************Constructed one neighbor network by attaching to the root sib: ";
        pNetCopy->Dump();
#endif
        listNgbrNetsDist1.push_back(pNetCopy);
    }
//#endif
}

void GenealogicalNetwork :: RetriveNgbrNetsOneEvtForMixEdge( GenealogicalNetworkBranch *pBranchToChange, vector<GenealogicalNetwork *> &listNgbrNetsDist1 ) const
{
//cout << "*** RetriveNgbrNetsOneEvtForMixEdge: network is: ";
//this->DumpMargTrees();
//cout << "Edge: ";
//pBranchToChange->Dump();
    
    // find neighbors based on an admixed edge
    GenealogicalNetworkNode *pnodeMix=pBranchToChange->GetSrcNode();
    GenealogicalNetworkNode *pnodeMixDesc=pBranchToChange->GetDestNode();
    YW_ASSERT_INFO(pnodeMix->IsMixNode(), "Fatal error");
    GenealogicalNetworkBranch *pmixBr1=pnodeMix->GetAnces1();
    GenealogicalNetworkBranch *pmixBr2=pnodeMix->GetAnces2();
    YW_ASSERT_INFO(pmixBr1!=NULL && pmixBr2!=NULL, "Cannot be null ancestors at mix");
    GenealogicalNetworkNode *pMixAncNode1=pmixBr1->GetSrcNode();
    GenealogicalNetworkNode *pMixAncNode2=pmixBr2->GetSrcNode();
    YW_ASSERT_INFO( pMixAncNode1!=NULL && pMixAncNode2!=NULL, "Cannot be null" );
    //
    vector<GenealogicalNetworkNode *> listAncNodestoSwap;
    bool fAnc1=pMixAncNode1->IsAncestralTo(pMixAncNode2);
    bool fAnc2=pMixAncNode2->IsAncestralTo(pMixAncNode1);
    if(fAnc1==false && fAnc2==false)
    {
        // try both way of changing
        listAncNodestoSwap.push_back( pMixAncNode1 );
        listAncNodestoSwap.push_back( pMixAncNode2 );
    }
    else
    {
        GenealogicalNetworkNode *pMixAncNode=pMixAncNode1;
        if( fAnc1 == true )
        {
            YW_ASSERT_INFO(fAnc2==false, "Wrong");
            pMixAncNode=pMixAncNode2;
        }
        if(fAnc2 == true )
        {
            YW_ASSERT_INFO(fAnc1==false, "Wrong");
        }
        listAncNodestoSwap.push_back(pMixAncNode);
    }
    
    for(int i=0; i<(int)listAncNodestoSwap.size(); ++i)
    {
        GenealogicalNetworkNode *pMixAncNode = listAncNodestoSwap[i];

        //
        GenealogicalNetworkNode *pnodeOther = pMixAncNode->GetOtherDescNode(pnodeMix);
        if( pnodeOther==NULL)
        {
            return;
        }
        map<GenealogicalNetworkNode *, GenealogicalNetworkNode*> mapOldNodeToNew;
        GenealogicalNetwork *pNetCopy = Copy( &mapOldNodeToNew );
        YW_ASSERT_INFO(mapOldNodeToNew.find( pnodeMix ) != mapOldNodeToNew.end(), "Fail to find3");
        YW_ASSERT_INFO(mapOldNodeToNew.find( pnodeMixDesc ) != mapOldNodeToNew.end(), "Fail to find4");
        GenealogicalNetworkBranch *pBrMixCopy = pNetCopy->GetBranch( mapOldNodeToNew[ pnodeMix ],  mapOldNodeToNew[ pnodeMixDesc ]);
        pBrMixCopy->DetachFromSrc();
        YW_ASSERT_INFO(mapOldNodeToNew.find( pMixAncNode ) != mapOldNodeToNew.end(), "Fail to find3");
        YW_ASSERT_INFO(mapOldNodeToNew.find( pnodeOther ) != mapOldNodeToNew.end(), "Fail to find4");
        GenealogicalNetworkBranch *pBrOtherCopy = pNetCopy->GetBranch( mapOldNodeToNew[ pMixAncNode ],  mapOldNodeToNew[ pnodeOther ]);
        pBrOtherCopy->DetachFromSrc();
        pBrMixCopy->AttachToSrc( mapOldNodeToNew[ pMixAncNode ], mapOldNodeToNew[ pnodeMixDesc ] );
        pBrOtherCopy->AttachToSrc( mapOldNodeToNew[ pnodeMix ], mapOldNodeToNew[pnodeOther] );
        // ensure the network is OK
        pNetCopy->RemoveTrivialCycles();
        
#if 0
        cout << "*****************Constructed one neighbor network by attaching to the root sib: ";
        pNetCopy->Dump();
        //pNetCopy->DumpMargTrees();
#endif
        listNgbrNetsDist1.push_back(pNetCopy);
    }
}

void GenealogicalNetwork :: RetriveNgbrNetsOneNewMixForEdge( GenealogicalNetworkBranch *pBranchToChange, vector<GenealogicalNetwork *> &listNetsOneNewMix ) const
{
//cout << "GenealogicalNetwork :: RetriveNgbrNetsOneNewMixForEdge: current net: ";
//this->DumpMargTrees(false);
//cout << "Edge: src: " << pBranchToChange->GetSrcNode()->GetTaxonId() << ", dest: " << pBranchToChange->GetDestNode()->GetTaxonId() << endl;
    
    // don't work on leaf branch (unless its leaf branch)
    if(pBranchToChange->IsLeafBranch()==false)
    {
        return;
    }
    
    // change where the branch attaches to and return all the possible networks
    set<GenealogicalNetworkBranch *> setBrsToReattach;
    FindReattachBranches( pBranchToChange, setBrsToReattach, false );   // for new mixing, avoid NNI: need to search for more choices
    
    // YW: 02/02/16: the number of mix nodes of new network should work better
    int numNetNodes = GetNumMixNodes();
    
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBrsToReattach.begin(); it != setBrsToReattach.end(); ++it )
    {
#if 0
        cout << "Now reattach to this branch: ";
        (*it)->Dump();
#endif
        map<GenealogicalNetworkNode *, GenealogicalNetworkNode*> mapOldNodeToNew;
        GenealogicalNetwork *pNetCopy = Copy( &mapOldNodeToNew );
#if 0
        cout << "Network copy: ";
        pNetCopy->DumpMargTrees(false);
        //pNetCopy->Dump();
#endif
        //
        GenealogicalNetworkNode *pnodeDest = pBranchToChange->GetDestNode();
        GenealogicalNetworkNode *pnodeSrc = pBranchToChange->GetSrcNode();
        YW_ASSERT_INFO(mapOldNodeToNew.find(pnodeDest) != mapOldNodeToNew.end(), "Fail to find1");
        YW_ASSERT_INFO(mapOldNodeToNew.find(pnodeSrc) != mapOldNodeToNew.end(), "Fail to find2");
        GenealogicalNetworkNode *pnodeSrcCopy = mapOldNodeToNew[pnodeSrc];
        GenealogicalNetworkNode *pnodeDestCopy = mapOldNodeToNew[pnodeDest];
        GenealogicalNetworkBranch *pBrSrc = pNetCopy->GetBranch( pnodeSrcCopy,  pnodeDestCopy);
        YW_ASSERT_INFO(mapOldNodeToNew.find((*it)->GetSrcNode() ) != mapOldNodeToNew.end(), "Fail to find3");
        YW_ASSERT_INFO(mapOldNodeToNew.find((*it)->GetDestNode() ) != mapOldNodeToNew.end(), "Fail to find4");
        GenealogicalNetworkBranch *pBrDestCopy = pNetCopy->GetBranch( mapOldNodeToNew[(*it)->GetSrcNode()],  mapOldNodeToNew[(*it)->GetDestNode()]);
        YW_ASSERT_INFO(pBrDestCopy != NULL, "Fail to find5");
        pNetCopy->AddMixBtwBranches( pBrSrc, pBrDestCopy );
        
        // ensure the network is OK
        pNetCopy->RemoveTrivialCycles();
        
#if 0
        cout << "*Constructed one neighbor network: ";
        pNetCopy->DumpMargTrees(false);
        //pNetCopy->Dump();
#endif
        
        // YW: 02/02/16: only accept the new candidate when the number of mix nodes of new network is larger
        // YW: is this really the good choice? Not sure yet
        if( pNetCopy->GetNumMixNodes() > numNetNodes )
        {
            listNetsOneNewMix.push_back(pNetCopy);
        }
        else
        {
            delete pNetCopy;
        }
    }

}

void GenealogicalNetwork :: FindReattachBranches( GenealogicalNetworkBranch *pBranchToChange, set<GenealogicalNetworkBranch *> &setBranchesToAttach, bool fUseNNIMode ) const
{
    // if this branch's source node is mixing, don't allow it to change
    if( pBranchToChange->IsSrcMixing() == true )
    {
        return;
    }
    
    
    // first, cannot use any edges that are descendent to the current edge
    set<GenealogicalNetworkBranch *> setAllBranches;
    GetAllBranches( setAllBranches );
    set<GenealogicalNetworkBranch *> setUsableBrs;
    for( set<GenealogicalNetworkBranch *> :: iterator it = setAllBranches.begin(); it != setAllBranches.end(); ++it)
    {
        // also don't allow if a branch share nodes with the changed edge
        // and do not allow mixing edges
        GenealogicalNetworkNode *pNodeSrc = pBranchToChange->GetSrcNode();
        GenealogicalNetworkNode *pNodeDest = pBranchToChange->GetDestNode();
        // are we in NNI mode
        if( fUseNNIMode == false )
        {
            //if( pBranchToChange->IsAncestralTo(*it) == false && (*it)->IsMixing() == false && (*it)->GetSrcNode() != pNodeSrc && (*it)->GetDestNode() != pNodeSrc && (*it)->GetSrcNode() != pNodeDest && (*it)->GetDestNode() != pNodeDest   )
            if( pBranchToChange->IsAncestralTo(*it) == false && (*it)->GetSrcNode() != pNodeSrc && (*it)->GetDestNode() != pNodeSrc && (*it)->GetSrcNode() != pNodeDest && (*it)->GetDestNode() != pNodeDest   )
            //if( pBranchToChange->IsAncestralTo(*it) == false && (*it)->IsMixing() == false && (*it)->GetSrcNode() != pNodeSrc && (*it)->GetDestNode() != pNodeSrc  )
            {
                //
                setUsableBrs.insert( *it );
            }
        }
        else
        {
            // only allow edges that are sibling of the current edge
            GenealogicalNetworkNode *pSrcOther = (*it)->GetSrcNode();
            //if( pBranchToChange->IsAncestralTo(*it) == false && pNodeSrc != NULL && pNodeSrc->IsMixNode() == false && pSrcOther != NULL  && pSrcOther->IsMixNode() == false &&  pNodeSrc->GetParentSingle() != NULL && pNodeSrc->GetParentSingle() == pSrcOther->GetParentSingle()  && (*it)->GetSrcNode() != pNodeSrc && (*it)->GetDestNode() != pNodeSrc && (*it)->GetSrcNode() != pNodeDest && (*it)->GetDestNode() != pNodeDest  )
            if( pBranchToChange->IsAncestralTo(*it) == false && pNodeSrc != NULL && pNodeSrc->IsMixNode() == false && pSrcOther != NULL  && pSrcOther->IsMixNode() == false &&  pNodeSrc->GetParentSingle() != NULL && pNodeSrc->GetParentSingle() == pSrcOther->GetParentSingle()  && (*it)->GetSrcNode() != pNodeSrc && (*it)->GetDestNode() != pNodeSrc && (*it)->GetSrcNode() != pNodeDest && (*it)->GetDestNode() != pNodeDest  )
            {
                setUsableBrs.insert(*it);
            }
        }
    }
    setBranchesToAttach = setUsableBrs;
}

GenealogicalNetwork * GenealogicalNetwork :: Copy( map<GenealogicalNetworkNode *, GenealogicalNetworkNode *> *pMapOldNodeToNew ) const
{
    // Make a copy of the current network
    // first create all the nodes
    GenealogicalNetwork *pNetNew = new GenealogicalNetwork();
    
    map<GenealogicalNetworkNode *, GenealogicalNetworkNode *> mapOldNodeToNew;
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
    {
        //
        GenealogicalNetworkNode *pnodeNew = new GenealogicalNetworkNode();
        pnodeNew->SetMixRatio( (*it)->GetMixRatio() );
        pnodeNew->SetTaxonId( (*it)->GetTaxonId() );
        pnodeNew->SetTaxonStrUser( (*it)->GetTaxonStrUser() );
        pNetNew->AddNode( pnodeNew );
        mapOldNodeToNew.insert( map<GenealogicalNetworkNode *, GenealogicalNetworkNode *> :: value_type( *it, pnodeNew ) );
    }
    // now create all the edges
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
    {
        GenealogicalNetworkNode *pSrc = (*it)->GetSrcNode();
        GenealogicalNetworkNode *pDest = (*it)->GetDestNode();
        GenealogicalNetworkBranch *pBrOld = GetBranch( (*it)->GetSrcNode(), (*it)->GetDestNode() );
        double lenOld = pBrOld->GetLength();
        YW_ASSERT_INFO( mapOldNodeToNew.find(pSrc) != mapOldNodeToNew.end(), "Fail to find" );
        YW_ASSERT_INFO( mapOldNodeToNew.find(pDest) != mapOldNodeToNew.end(), "Fail to find" );
        pNetNew->AddBranch( mapOldNodeToNew[pSrc], mapOldNodeToNew[pDest], lenOld );
    }
    
    if(pMapOldNodeToNew != NULL)
    {
        *pMapOldNodeToNew = mapOldNodeToNew;
    }
    
    return pNetNew;
}

void GenealogicalNetwork :: ReattachBranchTo( GenealogicalNetworkBranch *pBrSrc, GenealogicalNetworkBranch *pBrDest )
{
#if 0
cout << "ReattachBranchTo: pBrSrc: ";
pBrSrc->Dump();
cout << "   , pBrDest: ";
pBrDest->Dump();
cout << endl;
#endif
    // attach the pbrsrc to be as sibling as pBrDest
    GenealogicalNetworkNode *pNodeSrcOfOrig = pBrSrc->GetSrcNode();
    GenealogicalNetworkNode *pNodeDestOfOrig = pBrSrc->GetDestNode();
    GenealogicalNetworkNode *pNodeSrcOfSib = pBrDest->GetSrcNode();
    GenealogicalNetworkNode *pNodeDestOfSib = pBrDest->GetDestNode();
    
    double brSrcOrigLen = pBrSrc->GetLength();
    
    // attach in the middle of the new edge
    pBrSrc->DetachFromSrc();
    RemoveBranch( pNodeSrcOfOrig, pNodeDestOfOrig );
//cout << "After detach branch pBrSrc: " << endl;
    CleanupAt( pNodeSrcOfOrig );
#if 0
cout << "After cleanup by detaching pBrSrc: network becomes: ";
this->Dump();
#endif
    GenealogicalNetworkBranch *pBrToAttach = GetBranch(pNodeSrcOfSib, pNodeDestOfSib);
    double brOld = pBrToAttach->GetLength();
    pBrDest->DetachFromSrc();
    RemoveBranch( pNodeSrcOfSib, pNodeDestOfSib );
    GenealogicalNetworkBranch *pBrNew1=NULL;
    GenealogicalNetworkBranch *pBrNew2=NULL;
    GenealogicalNetworkNode *pnParNew = pNodeDestOfOrig->AddToSib( pNodeDestOfSib, brSrcOrigLen, 0.5*brOld, pBrNew1, pBrNew2 );
    this->AddNode( pnParNew );
    this->AddBranch( pNodeSrcOfSib, pnParNew, 0.5*brOld );
    YW_ASSERT_INFO( pBrNew1!=NULL&&pBrNew2 !=NULL, "Fail to add" );
    this->setBranches.insert( pBrNew1 );
    this->setBranches.insert( pBrNew2 );
}

void GenealogicalNetwork :: ReattachBranchAsRootSib(GenealogicalNetworkBranch *pBrSrc)
{
#if 0
    cout << "ReattachBranchAsRootSib: pBrSrc: ";
    pBrSrc->Dump();
    cout << endl;
#endif
    // attach the pbrsrc to be as sibling as pBrDest
    GenealogicalNetworkNode *pNodeSrcOfOrig = pBrSrc->GetSrcNode();
    GenealogicalNetworkNode *pNodeDestOfOrig = pBrSrc->GetDestNode();
    GenealogicalNetworkNode *pNodeRootCur = GetRoot();
    
    double brSrcOrigLen = pBrSrc->GetLength();
    
    // attach in the middle of the new edge
    pBrSrc->DetachFromSrc();
    RemoveBranch( pNodeSrcOfOrig, pNodeDestOfOrig );
    //cout << "After detach branch pBrSrc: " << endl;
    CleanupAt( pNodeSrcOfOrig );
#if 0
    cout << "After cleanup by detaching pBrSrc: network becomes: ";
    this->Dump();
#endif
    // new branch to root is set to a default value of 0.1
    const double LEN_DEF_ROOT_BRANCH = 0.1;
    double brOld = LEN_DEF_ROOT_BRANCH;
    GenealogicalNetworkBranch *pBrNew1=NULL;
    GenealogicalNetworkBranch *pBrNew2=NULL;
    GenealogicalNetworkNode *pNodeRootNew = pNodeDestOfOrig->AddToSib( pNodeRootCur, brSrcOrigLen, brOld, pBrNew1, pBrNew2 );
    this->AddNode( pNodeRootNew );
    YW_ASSERT_INFO( pBrNew1!=NULL&&pBrNew2 !=NULL, "Fail to add" );
    this->setBranches.insert( pBrNew1 );
    this->setBranches.insert( pBrNew2 );
}

void GenealogicalNetwork :: AddMixBtwBranches( GenealogicalNetworkBranch *pBrMixSink, GenealogicalNetworkBranch *pBrMixSource )
{
    //
#if 0
    cout << "AddMixBtwBranches: pBrMixSink: ";
    pBrMixSink->Dump();
    cout << "   , pBrMixSource: ";
    pBrMixSource->Dump();
    cout << endl;
#endif
    // attach the pbrsrc to be as sibling as pBrDest
    GenealogicalNetworkNode *pNodeSourceOfSink = pBrMixSink->GetSrcNode();
    GenealogicalNetworkNode *pNodeDestOfSink = pBrMixSink->GetDestNode();
    GenealogicalNetworkNode *pNodeSrcOfSource = pBrMixSource->GetSrcNode();
    GenealogicalNetworkNode *pNodeDestOfSource = pBrMixSource->GetDestNode();
    
    double brSrcSinkLen = pBrMixSink->GetLength();
    double brSrcSourceLen = pBrMixSource->GetLength();
    
    // attach in the middle of the new edge
    pBrMixSink->DetachFromSrc();
    RemoveBranch( pNodeSourceOfSink, pNodeDestOfSink );
    GenealogicalNetworkNode *pnMiddleNew = new GenealogicalNetworkNode;
    const double DEF_MIX_RATIO = 0.5;
    pnMiddleNew->SetMixRatio(DEF_MIX_RATIO);
    this->AddNode( pnMiddleNew );
    this->AddBranch( pNodeSourceOfSink, pnMiddleNew, 0.5*brSrcSinkLen );
    this->AddBranch( pnMiddleNew, pNodeDestOfSink, 0.5*brSrcSinkLen );

#if 0
    cout << "After cleanup by detaching pBrSrc: network becomes: ";
    this->Dump();
#endif
    GenealogicalNetworkBranch *pBrToAttach = GetBranch(pNodeSrcOfSource, pNodeDestOfSource);
    pBrMixSource->DetachFromSrc();
    RemoveBranch( pNodeSrcOfSource, pNodeDestOfSource );
    GenealogicalNetworkBranch *pBrNew1=NULL;
    GenealogicalNetworkBranch *pBrNew2=NULL;
    GenealogicalNetworkNode *pnParNew = pnMiddleNew->AddToSib( pNodeDestOfSource, brSrcSinkLen, 0.5*brSrcSourceLen, pBrNew1, pBrNew2 );
    this->AddNode( pnParNew );
    this->AddBranch( pNodeSrcOfSource, pnParNew, 0.5*brSrcSourceLen );
    YW_ASSERT_INFO( pBrNew1!=NULL&&pBrNew2 !=NULL, "Fail to add" );
    this->setBranches.insert( pBrNew1 );
    this->setBranches.insert( pBrNew2 );

}

void GenealogicalNetwork :: CleanupAt( GenealogicalNetworkNode *pNodeChanged )
{
    if( pNodeChanged == NULL )
    {
        return;
    }
#if 0
cout << "Cleanu: pNodeChanged: ";
pNodeChanged->Dump();
cout << endl;
#endif
    // after changing the network, clean up the structure at this node
    // if this node has no taxon and there is no children
    GenealogicalNetworkNode *pNodeAnc1 = NULL;
    if( pNodeChanged->GetAnces1() != NULL )
    {
        pNodeAnc1 = pNodeChanged->GetAnces1()->GetSrcNode();
    }
    GenealogicalNetworkNode *pNodeAnc2 = NULL;
    if( pNodeChanged->GetAnces2() != NULL )
    {
        pNodeAnc2 = pNodeChanged->GetAnces2()->GetSrcNode();
    }
    
    if( pNodeChanged->IsLeaf() == true )
    {
        if( pNodeChanged->HasTaxon() == false )
        {
//cout << "Cleanup at a leaf\n";
            // erase it and then cleanup each of its ancestor
            RemoveNode(pNodeChanged);
            CleanupAt( pNodeAnc1 );
            CleanupAt( pNodeAnc2 );
        }
    }
    else if( pNodeChanged->GetNumChildren() == 1 )
    {
        GenealogicalNetworkNode *pChildSingle = pNodeChanged->GetChildSingle();
#if 0
cout << "In cleanup: pChildSingle: ";
pChildSingle->Dump();
cout << endl;
#endif
        // if there are two paernts, don't do anything
        if( pNodeChanged->GetNumParents() <= 1 )
        {
            GenealogicalNetworkBranch *pBrOld = GetBranch(pNodeChanged, pChildSingle);
            YW_ASSERT_INFO(pBrOld!=NULL, "NULL");
            double brLenOld = pBrOld->GetLength();
            
            RemoveBranch( pNodeChanged, pChildSingle);
            pNodeChanged->RemoveChild(pChildSingle);
//cout << "Remove child1\n";
            
            // remove it
            GenealogicalNetworkNode *pParOrig = pNodeChanged->GetParentSingle();
            if( pParOrig != NULL )
            {
                GenealogicalNetworkBranch *pBrOld2 = GetBranch(pParOrig, pNodeChanged);
                YW_ASSERT_INFO(pBrOld2 != NULL, "NULL");
                brLenOld += pBrOld2->GetLength();
                pParOrig->RemoveChild( pNodeChanged );
//cout << "Remove child2\n";
                RemoveBranch( pParOrig, pNodeChanged );
                AddBranch( pParOrig, pChildSingle, brLenOld );
            }
            RemoveNode( pNodeChanged, false );
            //delete pNodeChanged;
        }
    }
//cout << "Cleanup: done\n";
}

void GenealogicalNetwork :: RemoveBranch( GenealogicalNetworkNode *pSrcNode, GenealogicalNetworkNode *pDestNode, bool fMem )
{
    //
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
    {
        if( (*it)->GetSrcNode() == pSrcNode && (*it)->GetDestNode() == pDestNode )
        {
            if( fMem == true )
            {
                delete *it;
            }
            setBranches.erase( *it);
            break;
        }
    }
}

void GenealogicalNetwork :: RemoveNode(GenealogicalNetworkNode *pNode, bool fRmBrs )
{
    // remove node and all attached edges
    if( fRmBrs)
    {
        set<GenealogicalNetworkBranch *> setBrsLeft;
        set<GenealogicalNetworkBranch *>setBrsRm;
        for( set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
        {
            if( (*it)->GetSrcNode() != pNode && (*it)->GetDestNode() != pNode )
            {
                setBrsLeft.insert(*it);
            }
            else
            {
                setBrsRm.insert(*it);
            }
        }
        setBranches = setBrsLeft;
        for( set<GenealogicalNetworkBranch *> :: iterator it = setBrsRm.begin(); it != setBrsRm.end(); ++it)
        {
            setBranches.erase(*it);
            delete *it;
        }
    }
    
    setNodes.erase(pNode);
    delete pNode;
}

void GenealogicalNetwork :: MapBackUserLabels(TaxaMapper &mapperTaxa)
{
    // process each node
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
    {
        //
        int idTaxaInternal = (*it)->GetTaxonId();
        if( idTaxaInternal < 0)
        {
            // this is an internal node so skip
            continue;
        }
        string strUserLbl = mapperTaxa.GetString( idTaxaInternal );
        (*it)->SetTaxonStrUser( strUserLbl );
    }
}

void GenealogicalNetwork :: MapBackUserLabelsByUserLabels(TaxaMapper &mapperTaxa)
{
    // ASSUME: the labels are in integers format
    // process each node
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
    {
        //
        string idTaxaInternalLbl = (*it)->GetTaxonStrUser();
        if( idTaxaInternalLbl.length() == 0)
        {
            // this is an internal node so skip
            continue;
        }
        int idTaxaInternal = atoi(idTaxaInternalLbl.c_str() );
        string strUserLbl = mapperTaxa.GetString( idTaxaInternal );
        (*it)->SetTaxonStrUser( strUserLbl );
    }
}

void GenealogicalNetwork :: OutputGML ( const char *inFileName )
{
	// Now output a file in GML format
	// First create a new name
	string name = inFileName;
    //cout << "num edges = " << listEdges.size() << endl;
    
	// Now open file to write out
	ofstream outFile( name.c_str() );
    
	// First output some header info
	outFile << "graph [\n";
	outFile << "comment ";
	OutputQuotedString(outFile, "Population network, automatically generated by Graphing tool");
	outFile << "\ndirected  1\n";
	outFile << "id  1\n";
	outFile << "label ";
	OutputQuotedString ( outFile, "Population network....");
    outFile << endl;
    //outFile << endl;
    
	// Now output all the vertices
    //	int i;

    //cout << "a.1.1\n";
    for( set<GenealogicalNetworkNode *> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
        GenealogicalNetworkNode *pnodeCur = *it;

		outFile << "node [\n";
        
		outFile << "id " <<  pnodeCur->GetID()  << endl;
		outFile << "label ";
 		string nameToUse = " ";
        string strLblUse = pnodeCur->GetTaxonStrUser();
        if( strLblUse.length() == 0 )
        {
            int taxonId = pnodeCur->GetTaxonId();
            if( taxonId >= 0 )
            {
                char buf[100];
                sprintf(buf,"%d", taxonId);
                nameToUse = buf;
            }
            else
            {
                // for mixing node, output mixing ratio
                if( pnodeCur->IsMixNode() == true )
                {
                    char buf[100];
                    sprintf(buf,"Mix:%.2f", pnodeCur->GetMixRatio() );
                    nameToUse = buf;
                }
            }
        }
        else
        {
            nameToUse = strLblUse;
        }

        const char *name = nameToUse.c_str();
        OutputQuotedString (outFile,  name  );
		outFile << endl;
        
        // See if we need special shape for mixing node
        if( pnodeCur->IsMixNode() == true )
        {
            outFile << "vgj [ \n shape  ";
            OutputQuotedString( outFile, "Rectangle");
    		outFile << "\n]\n";
        }
        else
        {
		    outFile << "defaultAtrribute   1\n";
        }
        
		outFile << "]\n";
	}
    //cout << "a.1.3\n";
    
	// Now output all the edges, by again starting from root and output all nodes
    for( set<GenealogicalNetworkBranch *> :: iterator it = setBranches.begin(); it != setBranches.end(); ++it)
    {
        GenealogicalNetworkNode *pnsrc = (*it)->GetSrcNode();
        GenealogicalNetworkNode *pndest = (*it)->GetDestNode();
        //cout << "Output an edge \n";
        outFile << "edge [\n";
        outFile << "source " << pnsrc->GetID() << endl;
        outFile << "target  " << pndest->GetID() << endl;
        outFile << "label " ;
        
        // output branch length
        double len = (*it)->GetLength();
        char buf[100];
        sprintf(buf, "%1.3f", len);
        
        OutputQuotedString( outFile, buf);
        outFile << "\n";
        outFile << "]\n";
	}
    
    
	// Finally quite after closing file
	outFile << "\n]\n";
	outFile.close();
}

void GenealogicalNetwork :: DumpMargTrees(bool fConv) const
{
    map<string,string> mapTaxonIdToUserId;
    CreateMapTaxonIdToUserId( mapTaxonIdToUserId );
//cout << "mapTaxonIdToUserId: ";
//for( map<string,string> ::iterator it = mapTaxonIdToUserId.begin(); it!= mapTaxonIdToUserId.end(); ++it )
//{
//cout << it->first   << " to "  << it->second << "  ";
//}
    
    // output all marginal trees
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    RetriveAllMarginalTrees( mapMargTreesWithFreq );
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo>::const_iterator it= mapMargTreesWithFreq.begin(); it != mapMargTreesWithFreq.end(); ++it )
    {
        // format: [freq] newick-format-tree
        cout << "[" << it->second.GetFreq() << "] ";
        string strNWTree = it->second.GetMargTree()->GetNewick() ;
//cout << "Before convert: tree is " << strNWTree << endl;
        if( fConv == true )
        {
            NewickUtils:: UpdateLabells( strNWTree, mapTaxonIdToUserId );
        }
//cout << "AFTER convert: tree is " << strNWTree << endl;
        cout << strNWTree << endl;
        it->second.FreeTree();
    }
    // also dump out admixture
    //DumpAdmixNodes();
}

void GenealogicalNetwork :: DumpAdmixNodes() const
{
    //
    // find all the admixture nodes
    vector<GenealogicalNetworkNode *> listMixNodes;
    GetMixNodes( listMixNodes );
    for(int i=0; i<(int)listMixNodes.size(); ++i)
    {
        cout << "Admixture population: ";
        set<string> setLvTaxaIds;
        listMixNodes[i]->GetAllLeafTaxonIdsUnder(setLvTaxaIds);
        if( setLvTaxaIds.size() == 1 )
        {
            cout << *( setLvTaxaIds.begin() ) << endl;
        }
        else if(setLvTaxaIds.size() > 1 )
        {
            cout << "(";
            for(set<string> :: iterator it2 = setLvTaxaIds.begin(); it2 != setLvTaxaIds.end(); ++it2)
            {
                if( it2 != setLvTaxaIds.begin() )
                {
                    cout << ",";
                }
                cout << *it2;
            }
            cout << ")\n";
        }
    }
}

void GenealogicalNetwork :: CreateMapTaxonIdToUserId( map<string,string> &mapTaxonIdToUserId ) const
{
    //
    for( set<GenealogicalNetworkNode *> :: const_iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
        GenealogicalNetworkNode *pnodeCur = *it;
        char buf[100];
        sprintf(buf, "%d", pnodeCur->GetTaxonId() );
        string bufstr = buf;
        string taxonStrUser = pnodeCur->GetTaxonStrUser();
        mapTaxonIdToUserId.insert( map<string,string>  :: value_type(bufstr, taxonStrUser) );
    }
}

void GenealogicalNetwork :: GetAllTaxa(set<int> &setTaxa) const
{
    vector<GenealogicalNetworkNode *> listLeaves;
    GetLeaves( listLeaves );
    setTaxa.clear();
    for(int i=0; i<(int)listLeaves.size(); ++i)
    {
        setTaxa.insert( listLeaves[i]->GetTaxonId() );
    }
}


