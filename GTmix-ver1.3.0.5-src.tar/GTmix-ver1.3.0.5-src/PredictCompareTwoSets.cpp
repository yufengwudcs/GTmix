//
//  PredictCompareTwoSets.cpp
//  
//
//  Created by Yufeng Wu on 1/29/16.
//
//

#include "PredictCompareTwoSets.h"



#if 0
//***********************************************************************************
// Assume:
// item has < operator which allows them to be in the container class like set

const double defWinThresHold = 0.75;

//***********************************************************************************
// Predictor

template<class T>
TwoSetsComparisonPredictor:: TwoSetsComparisonPredictor() : fracWinningThreshold(defWinThresHold)
{
}

template<class T>
void TwoSetsComparisonPredictor :: OneSetBeatOther( const set<set<T> > &setWinner, const set<set<T> > &setLoser )
{
    //
    for( set<set<T> > :: const_iterator it1 = setWinner.begin(); it1 != setWinner.end(); ++it1 )
    {
        for( set<set<T> > :: const_iterator it2 = setLoser.begin(); it2 != setLoser.end(); ++it2 )
        {
            if( IsRelevant( *it1, *it2 ) == true )
            {
                OneItemBeatOther( *it1, *it2 );
            }
        }
    }
}

template<class T>
bool TwoSetsComparisonPredictor :: PredictWinner( const set<set<T> > &setChallenger, const set<set<T> > &setEstablished )
{
    // common items are excluded
    bool fRes = true;
    bool fDiff = false;
    
    // each non-common item should be
    for( set<set<T> > :: const_iterator it1 = setChallenger.begin(); it1 != setChallenger.end(); ++it1)
    {
        if( setEstablished.find(*it1) != setEstablished.end() )
        {
            continue;
        }
        
        //
        for( set<set<T> > :: const_iterator it2 = setChallenger.begin(); it2 != setChallenger.end(); ++it2 )
        {
            //
            if( *it1 == *it2 )
            {
                //
                continue;
            }
            
            //
            fDiff = true;
            
            //
            bool fBeaten = IsBetter( *it2, *it1 );
            if( fBeaten == true )
            {
                fRes = false;
                break;
            }
        }
    }
    return fRes && FDiff;
}

template<class T>
bool TwoSetsComparisonPredictor :: IsRelevant( const set<T> &item1, const set<T> &item2)
{
    // true if the two sets intersect
    return AreSetsIntersecting( item1, item2 );
}

template<class T>
double TwoSetsComparisonPredictor :: CalcScore( const set<T> &s1, const set<T> &s2 )
{
    pair<set<T>, set<T> > pp(s1,s2);
    
    if( mapScoreMatTwoItems.find(pp) == mapScoreMatTwoItems.end() )
    {
        // not seen before
        return 0.0;
    }
    
    int numCmpTimes = mapScoreMatTwoItems[pp].first;
    double cmpScore = mapScoreMatTwoItems[pp].second;
    return cmpScore/numCmpTimes;
}

template<class T>
void TwoSetsComparisonPredictor :: OneItemBeatOther( const set<T> &itemWinner, const set<T> &itemLoser )
{
    //
    set<T> itemWinnerUse = itemWinner;
    set<T> itemLoserUse = itemLoser;
    bool fOrder = OrderTwoItems( itemWinnerUse, itemLoserUse );
    double score = 1.0;     // each time win once
    if( fOrder == true )
    {
        score = -1.0;
    }
    pair< set<T>, set<T> > pp(itemWinnerUse, itemLoserUse);
    if( mapScoreMatTwoItems.find(pp) == mapScoreMatTwoItems.end() )
    {
        pair<int,double> pp2(0, 0.0);
        mapScoreMatTwoItems.insert( map< pair<set<T>, set<T> >, pair<int,double> > :: value_type(pp, pp2) );
    }
    ++mapScoreMatTwoItems[pp].first;
    mapScoreMatTwoItems[pp].second += score;
}

template<class T>
bool TwoSetsComparisonPredictor :: IsBetter( const set<T>& itemGood, const set<T>& itemBad )
{
    //
    set<T> itemGoodUse=itemGood;
    set<T> itemBadUse=itemBad;
    bool fSwitch = OrderTwoItems( itemGoodUse, itemBadUse );
    
    double score = CalcScore( itemGoodUse, itemBadUse );
    if( fSwitch == false && score >= fracWinningThreshold  )
    {
        return true;
    }
    else if( fSwitch == false && score < -1.0* fracWinningThreshold )
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<class T>
bool TwoSetsComparisonPredictor :: OrderTwoItems( set<T> &item1, set<T> &item2)
{
    // return true if switched
    bool res = false;
    if( (item1 < item2) == false)
    {
        set<T> tmp=item2;
        item2 = item1;
        item1 = tmp;
        res = true;
    }
    return res;
}


#endif
