//
//  GenealogicalNetworkLenOpt.h
//  
//
//  Created by Yufeng Wu on 1/6/16.
//  Optimize network branch lengths for a given network
//

#ifndef ____GenealogicalNetworkLenOpt__
#define ____GenealogicalNetworkLenOpt__

#include "UtilsNumerical.h"
#include "GenealogicalNetwork.h"
#include "GenealogicalNetworkProb.h"

class PhylogenyTreeBasic;

//***********************************************************************************
// Optimize branch lengths of a given network topology wrt gene trees

class GenealogicalNetworkLenOpt : public NumericalAlgoUtils
{
public:
    GenealogicalNetworkLenOpt(GenealogicalNetwork &netIn, vector<PhylogenyTreeBasic *> &listGeneTreesIn);
    ~GenealogicalNetworkLenOpt();
    double CalcProb() { return pprobCompute->CalcProb(); }
    double Optimize();
    virtual double EvaluateAt(double pt, void *pParam);
    void SetMultithread(bool f);
    static void SetCompositeSzTaxa(int sz);
    static int GetCompositeSzTaxa();
    
private:
    void UpdateProbComputeForBranch( GenealogicalNetworkBranch *pBrToChange, double brNew );
    void UpdateProbComputeForMR( GenealogicalNetworkNode *pNodeMRChange, double mrNew );
    double GetMinBrLen(int round, double brLenCur) const;
    double GetMaxBrLen(int round, double brLenCur) const;
    double GetTolBrLen(int round) const;
    double GetMinMR(int round, double mrCur) const;
    double GetMaxMR(int round, double mrCur) const;
    double GetTolMR(int round) const;
    void SnapBrLens(GenealogicalNetwork &networkCurrent);
    
    GenealogicalNetwork &network;
    vector<PhylogenyTreeBasic *> &listGeneTrees;
    AbstractGenealogicalNetworkProb *pprobCompute;
    GenealogicalNetworkBranch *pBranchInNetCur;
    GenealogicalNetworkNode *pMixNodeCur;
    set<GenealogicalNetworkBranch *> setBranchesSkip;
    set<GenealogicalNetworkNode *> setMixNodesSkip;
    bool fMultiThreadAllowed;
    static int szTaxaComposte;
};



#endif /* defined(____GenealogicalNetworkLenOpt__) */
