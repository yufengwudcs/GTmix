//
//  GenealogicalNetworkProb.h
//  
//
//  Created by Yufeng Wu on 1/5/16.
//  Compute the probability of genealogical networks
//

#ifndef ____GenealogicalNetworkProb__
#define ____GenealogicalNetworkProb__

#include <vector>
using namespace std;

#include "GenealogicalNetwork.h"

class PhylogenyTreeBasic;
class MarginalTree;
class GenericGeneSpeciesTreeProb;

//***********************************************************************************
// Base class for calc prob of genealogical networks

class AbstractGenealogicalNetworkProb
{
public:
    virtual ~AbstractGenealogicalNetworkProb() {}
    virtual double CalcProb() = 0;
    virtual void UpdateBranch( GenealogicalNetworkBranch *pBrChange ) = 0;
    virtual void UpdateWts() = 0;
    virtual void SetMultithread(bool f) { }
    
protected:
    virtual GenericGeneSpeciesTreeProb *CreateProbCalcFor( MarginalTree *pMargTree, PhylogenyTreeBasic *pGeneTree );
};

//***********************************************************************************
// Calc prob of genealogical networks

class GenealogicalNetworkProb : public AbstractGenealogicalNetworkProb
{
public:
    GenealogicalNetworkProb(GenealogicalNetwork &netIn, vector<PhylogenyTreeBasic *> &listGeneTreesIn);
    virtual ~GenealogicalNetworkProb();
    virtual double CalcProb();
    virtual void UpdateBranch( GenealogicalNetworkBranch *pBrChange );
    virtual void UpdateWts();
    virtual void SetMultithread(bool f) { fMultithread = f; }
    static void SetNumThreads(int t);
    
private:
    void Clear();
    void ClearAt(int indexMT);
    void Init();
    bool IsInit();
    void CreateProbCalc();
    //GenericGeneSpeciesTreeProb *CreateProbCalcFor( MarginalTree *pMargTree, PhylogenyTreeBasic *pGeneTree );
    int GetIndexForNetcode( const GenealogicalNetworkMTreeCode &ncode );
    void ReinitMargTree(int indexMT, MarginalTree *pMargTreeNew);
    void SetAllMargTreeDirty();
    void SetMargTreeDirty(int pos);
    bool IsMargTreeFresh(int pos);
    void SetAllMargTreeFresh();
    double GetCachedProbValFor(int gtIndex, int mtIndex);
    void SetCachedProbValFor(int gtIndex, int mtIndex, double val);
    double CalcProbFromCached();
    double CalcProbMultithread();
    bool IsFresh() const { return fFresh; }
    void SetFresh(bool f ) { fFresh = f; }
    
    GenealogicalNetwork &network;
    vector<PhylogenyTreeBasic *> &listGeneTrees;
    vector< vector<GenericGeneSpeciesTreeProb *> > listGenetreeProbPtrs;
    vector<MarginalTree *> listMargTreesInNet;
    vector<double> listGenetreeProbWts;
    map<GenealogicalNetworkMTreeCode, int> mapNetCodeIndex;
    vector<bool> listMargTreeFresh;             // is marginal tree changed or not
    vector<vector<double> > listCachedProbs;    // to avoid recomputing
    bool fMultithread;
    bool fFresh;
    static int numThreads;
};

//***********************************************************************************
// Calc prob of genealogical networks

class GenealogicalNetworkProbComposite : public AbstractGenealogicalNetworkProb
{
public:
    GenealogicalNetworkProbComposite(GenealogicalNetwork &netIn, vector<PhylogenyTreeBasic *> &listGeneTreesIn, int szSubsetTaxaIn);
    virtual ~GenealogicalNetworkProbComposite();
    virtual double CalcProb();
    virtual void UpdateBranch( GenealogicalNetworkBranch *pBrChange );
    virtual void UpdateWts();
    
private:
    void Clear();
    void CreateAllProbCalc();
    void CreateSubGenetrees();
    double GetSubMargTreeWt(const set<int> &staxa, int indexTree) const;
    PhylogenyTreeBasic *GetSubGenetree( int gindex, const set<int> &staxa ) const;
    
    GenealogicalNetwork &network;
    vector<PhylogenyTreeBasic *> &listGeneTrees;
    int szSubsetTaxa;
    vector<map<set<int>, PhylogenyTreeBasic * > > listSubGeneTreesPtr;
    vector< map<set<int>,vector<GenericGeneSpeciesTreeProb *> > > listGenetreeProbPtrs;
    map<set<int>, vector<MarginalTree *> > listSubMargTreesInNet;
    map<set<int>, vector<double> > listSubMargTreesWts;
};


#endif /* defined(____GenealogicalNetworkProb__) */
