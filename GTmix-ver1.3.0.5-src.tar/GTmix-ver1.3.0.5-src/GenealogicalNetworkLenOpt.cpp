//
//  GenealogicalNetworkLenOpt.cpp
//  
//
//  Created by Yufeng Wu on 1/6/16.
//
//

#include "GenealogicalNetworkLenOpt.h"
#include "GenealogicalNetworkProb.h"
#include "GenealogicalNetworkProbStore.h"

//***********************************************************************************
// Optimize branch lengths of a given network topology wrt gene trees

int GenealogicalNetworkLenOpt :: szTaxaComposte = -1;
int maxNumOptRound = 1;

void GenealogicalNetworkLenOpt :: SetCompositeSzTaxa(int sz)
{
    szTaxaComposte = sz;
}

int GenealogicalNetworkLenOpt :: GetCompositeSzTaxa()
{
    return szTaxaComposte;
}

GenealogicalNetworkLenOpt :: GenealogicalNetworkLenOpt(GenealogicalNetwork &netIn, vector<PhylogenyTreeBasic *> &listGeneTreesIn) : network(netIn), listGeneTrees(listGeneTreesIn), pBranchInNetCur(NULL), pMixNodeCur(NULL), fMultiThreadAllowed(true)
{
    //Init();
    if( szTaxaComposte <= 0 )
    {
        pprobCompute = new GenealogicalNetworkProb(netIn, listGeneTreesIn);
    }
    else
    {
        pprobCompute = new GenealogicalNetworkProbComposite(netIn, listGeneTreesIn, szTaxaComposte);
    }
}

GenealogicalNetworkLenOpt:: ~GenealogicalNetworkLenOpt()
{
    if( pprobCompute != NULL)
    {
        delete pprobCompute;
        pprobCompute = NULL;
    }
}

void GenealogicalNetworkLenOpt :: SetMultithread(bool f)
{
    fMultiThreadAllowed = f;
    pprobCompute->SetMultithread(f);
}

double GenealogicalNetworkLenOpt :: Optimize()
{
    // snap all edge length
    SnapBrLens(this->network);
    //cout << "Before optimize, network: ";
    //this->network.DumpMargTrees(false);
    
    // optimize over the branch lengths by iterate through all branches
    set<GenealogicalNetworkBranch *> setAllBranchesInNet;
    network.GetAllBranches( setAllBranchesInNet );
    
    double loglikeliBest = MAX_NEG_DOUBLE_VAL;
    
//cout << "^^^^^Optimizing branch length: \n";
    int round = 0;
    while(true)
    {
        //
        double loglikeliStep = MAX_NEG_DOUBLE_VAL;
        for( set<GenealogicalNetworkBranch *>::iterator it= setAllBranchesInNet.begin(); it != setAllBranchesInNet.end(); ++it )
        {
            //
            pBranchInNetCur = *it;
            
            if( setBranchesSkip.find(pBranchInNetCur) != setBranchesSkip.end() )
            {
                continue;
            }
            
            pMixNodeCur = NULL;
            double brCurStep = pBranchInNetCur->GetLength();
            double brCurNew = 0.0;
            double brMin = GetMinBrLen(round, brCurStep);
            double brMax = GetMaxBrLen(round, brCurStep);
            double tolBr = GetTolBrLen(round);
//cout << "BRENT (length): [" << brMin << "," << brMax << "]: tol: " << tolBr << endl;
            double loglikeliStepStep = -1.0*Func1DMinBrent( brMin, brCurStep, brMax, tolBr,  &brCurNew);
//cout << "Orig len: " << brCurStep << ", new len: " << brCurNew;
            brCurNew = GTBranchLengthGrid::Instance().SnapToGrid(brCurNew);
//cout << "After snapping, new length: " << brCurNew << endl;
//cout << "Orig len: " << brCurStep << ", new len: " << brCurNew;
//cout << "   one round of Brent: best log-likelihood: " << loglikeliStepStep << endl;
            
            if( IsSignificantlyLarge( loglikeliStepStep, loglikeliStep ) == false )
            {
                // this branch does not change much
                setBranchesSkip.insert( pBranchInNetCur );
            }
            else
            {
                pBranchInNetCur->SetLength( brCurNew );
                loglikeliStep = loglikeliStepStep;
            }
        }
        // now search over all mixing node to adjust mixing coefficients
        vector<GenealogicalNetworkNode *> listMixNodes;
        network.GetMixNodes( listMixNodes );
        for(int i=0; i<(int)listMixNodes.size(); ++i)
        {
            pMixNodeCur = listMixNodes[i];
            if( setMixNodesSkip.find( pMixNodeCur) != setMixNodesSkip.end() )
            {
                continue;
            }
            
            pBranchInNetCur = NULL;
            double mrCur = pMixNodeCur->GetMixRatio();
            double mrBest = mrCur;
            double mrMin = GetMinMR(round, mrCur);
            double mrMax = GetMaxMR(round, mrCur);
            double tolMr = GetTolMR(round);
//cout << "BRENT (mix ratio): [" << mrMin << "," << mrMax << "]: tol: " << tolMr << endl;
            double loglikeliStepStep2 = -1.0*Func1DMinBrent(mrMin, mrCur, mrMax, tolMr, &mrBest);
//cout << "Orig mr: " << mrCur << ", new mr: " << mrBest;
            mrBest = GTBranchLengthGrid::Instance().SnapMRToGrid(mrBest);
//cout << "After snap, new mr: " << mrBest << endl;
//cout << "Orig mr: " << mrCur << ", new mr: " << mrBest;
//cout << "   one round of Brent: best log-likelihood: " << loglikeliStepStep2 << endl;
            
            if( IsSignificantlyLarge( loglikeliStepStep2, loglikeliStep ) == false )
            {
                // this branch does not change much
                setMixNodesSkip.insert( pMixNodeCur );
            }
            else
            {
                pMixNodeCur->SetMixRatio(mrBest);
                loglikeliStep = loglikeliStepStep2;
            }
        }
        
//cout << "[round " << round << "] At one round of branch length search: prev lokelihood: " << loglikeliBest << ", improved likelihood: " << loglikeliStep << endl;
        // stop if the likelihood value does not improve significantly
        if( IsSignificantlyLarge( loglikeliStep, loglikeliBest ) == false )
        {
            loglikeliBest = loglikeliStep;
            break;
        }
        else
        {
            loglikeliBest = loglikeliStep;
        }
        ++round;
        
        if( round >= maxNumOptRound )
        {
            break;
        }
    }
    
    return loglikeliBest;
}

double GenealogicalNetworkLenOpt :: EvaluateAt(double pt, void *pParam)
{
//cout << "___________Now updating branch length to: " << pt << " for branch: ";
//pBranchInNetCur->Dump();
    //
    double lenUse = GTBranchLengthGrid::Instance().SnapToGrid(pt);
    if( pBranchInNetCur != NULL )
    {
        UpdateProbComputeForBranch( pBranchInNetCur , lenUse );
    }
    else
    {
        double mrUse = GTBranchLengthGrid::Instance().SnapMRToGrid(pt);
        UpdateProbComputeForMR( pMixNodeCur, mrUse );
    }
    return -1.0*pprobCompute->CalcProb();
}

void GenealogicalNetworkLenOpt :: UpdateProbComputeForBranch( GenealogicalNetworkBranch *pBrToChange, double brNew )
{
    // find the affected marginal trees
    pBrToChange->SetLength(brNew);
    pprobCompute->UpdateBranch( pBrToChange );
}

void GenealogicalNetworkLenOpt :: UpdateProbComputeForMR( GenealogicalNetworkNode *pNodeMRChange, double mrNew )
{
    YW_ASSERT_INFO( pNodeMRChange != NULL, "Fail" );
    //
    pNodeMRChange->SetMixRatio( mrNew );
    pprobCompute->UpdateWts();
}

const double MIN_BR_LEN = 0.001;
const double MAX_BR_LEN = 1.0;
//const double TOL_BR_LEN = 0.001;
const double TOL_BR_LEN_INIT = 0.01;
const double TOL_BR_LEN_MIN = 0.001;
const double MIN_MR = 0.01;
const double MAX_MR = 0.99;
//const double MIN_MR = 0.4;
//const double MAX_MR = 0.6;
const double TOL_MR_MIN = 0.01;
const double TOL_MR_INIT = 0.05;

static double GNLOFactor(int round)
{
    const double facInit = 8.0;
    double res = facInit/( 0x1 << round );
    if( res < 2.0 )
    {
        res = 2.0;
    }
    return res;
}

double GenealogicalNetworkLenOpt :: GetMinBrLen(int round, double brLenCur) const
{
    if( round == 0 )
    {
        return MIN_BR_LEN;
    }
    else
    {
        double fac=GNLOFactor(round);
        double len = brLenCur/fac;
        if( len < MIN_BR_LEN)
        {
            len = MIN_BR_LEN;
        }
        return len;
    }
}
double GenealogicalNetworkLenOpt :: GetMaxBrLen(int round, double brLenCur) const
{
    if( round == 0 )
    {
        return MAX_BR_LEN;
    }
    else
    {
        double fac=GNLOFactor(round);
        double len = brLenCur*fac;
        if( len > MAX_BR_LEN)
        {
            len = MAX_BR_LEN;
        }
        return len;
    }
}
double GenealogicalNetworkLenOpt :: GetTolBrLen(int round) const
{
    if( round == 0)
    {
        return TOL_BR_LEN_INIT;
    }
    else
    {
        double tol = TOL_BR_LEN_INIT;
        tol = tol/(0x1 << round );
        if( tol < TOL_BR_LEN_MIN)
        {
            tol = TOL_BR_LEN_MIN;
        }
        return tol;
    }
}
double GenealogicalNetworkLenOpt :: GetMinMR(int round, double mrCur) const
{
//    return MIN_MR;
//#if 0
    if( round == 0 )
    {
        return MIN_MR;
    }
    else
    {
        double fac=GNLOFactor(round);
        double len = mrCur/fac;
        if( len < MIN_MR)
        {
            len = MIN_MR;
        }
        return len;
    }
//#endif
}
double GenealogicalNetworkLenOpt :: GetMaxMR(int round, double mrCur) const
{
//    return MAX_MR;
//#if 0
    if( round == 0 )
    {
        return MAX_MR;
    }
    else
    {
        double fac=GNLOFactor(round);
        double len = mrCur*fac;
        if( len > MAX_MR)
        {
            len = MAX_MR;
        }
        return len;
    }
//#endif
}
double GenealogicalNetworkLenOpt :: GetTolMR(int round) const
{
    //return TOL_MR_MIN;
//#if 0
    if( round == 0)
    {
        return TOL_MR_INIT;
    }
    else
    {
        double tol = TOL_MR_INIT;
        tol = tol/(0x1 << round );
        if( tol < TOL_MR_MIN)
        {
            tol = TOL_MR_MIN;
        }
        return tol;
    }
//#endif
}


void GenealogicalNetworkLenOpt :: SnapBrLens(GenealogicalNetwork &networkCurrent)
{
    //return;
    //
    set<GenealogicalNetworkBranch *> setAllBranchesInNet;
    networkCurrent.GetAllBranches( setAllBranchesInNet );
    for( set<GenealogicalNetworkBranch *> :: iterator it = setAllBranchesInNet.begin(); it != setAllBranchesInNet.end(); ++it )
    {
        GenealogicalNetworkBranch *pBr = *it;
        double brCurr = pBr->GetLength();
        double brConv = GTBranchLengthGrid::Instance().SnapToGrid(brCurr);
        pBr->SetLength(brConv);
    }
    vector<GenealogicalNetworkNode *> listMixNodes;
    network.GetMixNodes( listMixNodes );
    for(int i=0; i<(int)listMixNodes.size(); ++i)
    {
        double mr = listMixNodes[i]->GetMixRatio();
        double mrConv = GTBranchLengthGrid::Instance().SnapMRToGrid(mr);
        listMixNodes[i]->SetMixRatio(mrConv);
    }
}

