//
//  MultiBinaryMatrices.cpp
//  
//
//  Created by Yufeng Wu on 10/30/13.
//
//

#include "MultiBinaryMatrices.h"

//*********************************************************************
// Utilties to process a list of matrices

MultiBinaryMatrices :: MultiBinaryMatrices()
{
}

// assume: (1) matrices are sepeately by //,
// (2) there can be other lines but must have a line starting with "positions:" followed
// by positions of the sites
// (3) after that line, all binary lines
// (4) then an empty line, sepearating this matrix from others
bool MultiBinaryMatrices :: ReadFromFile(const char *fileName)
{
    //
    listInputMatrices.clear();
    
    // read in from file
    ifstream inFile(fileName);
	if(!inFile)
	{
		cout << "Can not open "<< fileName <<endl;
		exit(1);
	}
    
    char buf[MAX_SITE_NUM];		// assume maximum sites allowed are 4096
    
    bool fLookForPosition = false;
    while( inFile.eof() == false )
    {
        // look for the first "//"
        const int BUF_SZ = MAX_SITE_NUM*sizeof(int);
        inFile.getline(buf, BUF_SZ);
        string strInput = buf;
        if( strInput == "//")
        {
            // mark the begining of the
            fLookForPosition = true;
        }
        else if( fLookForPosition == true )
        {
            // check whether the line starts w/ "Positions:"
            if( strncmp(buf, "positions", 9) == 0 )
            {
                // now start reading a matrix
                BinaryMatrix inputMat;
                if( inputMat.ReadFromFile (inFile, false ) == false )
                {
                    // something wrong
                    return false;
                }
                listInputMatrices.push_back( inputMat );
            }
        }
    }
    inFile.close();
    
    return true;
}

void MultiBinaryMatrices :: Dump() const
{
    //
    cout << "Number of matrices: " << listInputMatrices.size() << endl;
    for(int i=0; i<(int)listInputMatrices.size(); ++i)
    {
        //
        cout << "//\n";
        listInputMatrices[i].Dump();
    }
}

