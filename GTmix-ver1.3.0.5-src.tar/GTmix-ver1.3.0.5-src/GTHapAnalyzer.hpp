//
//  GTHapAnalyzer.hpp
//  
//
//  Created by Yufeng Wu on 4/10/19.
//
//

#ifndef GTHapAnalyzer_hpp
#define GTHapAnalyzer_hpp

#include "MultiBinaryMatrices.h"

//***********************************************************************************
// Build initial tree from haplotypes

class ScaffoldTreeHapBuillder
{
public:
    ScaffoldTreeHapBuillder( MultiBinaryMatrices &listHapMatsIn, const vector<vector<int> > &listPopRowsIn );
    string Build();
    
private:
    double CalcDistTwoPops(int p1, int p2);
    double CalcDistTwoHaps(int h1, int h2);
    int GetNumPops() const { return listPopRows.size(); }
    
    MultiBinaryMatrices &listHapMats;
    const vector<vector<int> > &listPopRows;
};


#endif /* GTHapAnalyzer_hpp */
