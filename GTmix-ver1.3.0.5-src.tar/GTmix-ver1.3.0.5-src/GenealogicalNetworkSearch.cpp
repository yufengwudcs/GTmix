//
//  GenealogicalNetworkSearch.cpp
//  
//
//  Created by Yufeng Wu on 1/7/16.
//
//

#include "GenealogicalNetworkSearch.h"
#include "GenealogicalNetworkLenOpt.h"
#include "PhylogenyTreeBasic.h"
#include "Utils4.h"
#include <cmath>
#include "pthread.h"

const int DEF_MAX_NUM_NET_NODES = 1;
const double MIN_INC_RATIO = 1.0001;          // YW: does this threshold really matter?
static bool fFastSearch = true;


void SetFastSearch(bool f)
{
    fFastSearch = f;
}

//***********************************************************************************
// Search info for optimal network


GenealogicalNetworkSearchInfo :: GenealogicalNetworkSearchInfo() : numNetsProcessed(0), numNetsSkipped(0)
{
}
void GenealogicalNetworkSearchInfo :: ProcNet(GenealogicalNetwork *pnet)
{
    ++numNetsProcessed;
}

void GenealogicalNetworkSearchInfo :: SkipNet(GenealogicalNetwork *pnet)
{
    ++numNetsSkipped;
}

void GenealogicalNetworkSearchInfo :: Dump() const
{
    cout << "Number of networks searched: " << this->numNetsProcessed << endl;
    cout << "Number of networks skipped: " << this->numNetsSkipped << endl;
}



//***********************************************************************************
// Search info for optimal network

GenealogicalNetworkSearch :: GenealogicalNetworkSearch(GenealogicalNetwork &netInit, vector<PhylogenyTreeBasic *> &listGeneTreesIn) : pnetworkOpt(NULL), networkInit(netInit), listGeneTrees(listGeneTreesIn), maxNumMixNodes( DEF_MAX_NUM_NET_NODES ), logprobBestCurr(MAX_NEG_DOUBLE_VAL)
{
}

GenealogicalNetworkSearch :: ~GenealogicalNetworkSearch()
{
    if( pnetworkOpt != NULL )
    {
        delete pnetworkOpt;
    }
}

int GenealogicalNetworkSearch :: numThreads = 1;
int GenealogicalNetworkSearch :: taxonOutgroup = -1;

void GenealogicalNetworkSearch :: SetNumThreads(int t)
{
    numThreads = t;
}
void GenealogicalNetworkSearch :: SetOutgroup(int r)
{
//cout << "Interval outgroup id: " << r << endl;
    taxonOutgroup = r;
}
int GenealogicalNetworkSearch :: GetOutgroup()
{
    return taxonOutgroup;
}
bool GenealogicalNetworkSearch :: IsNetworkOGGood( const GenealogicalNetwork &netTest )
{
    // if outgroup is set, then each embedded tree should be consistent with the outgroup: yes each
    if( taxonOutgroup < 0 )
    {
        return true;
    }
//cout << "IsNetworkOGGood: network is ";
//netTest.DumpMargTrees(false);
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    netTest.RetriveAllMarginalTrees( mapMargTreesWithFreq );
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapMargTreesWithFreq.begin(); it != mapMargTreesWithFreq.end(); ++it )
    {
        MarginalTree *ptree = it->second.GetMargTree();
        if( ptree->IsOutgroup( taxonOutgroup ) == false )
        {
            return false;
        }
    }
    return true;
}


double GenealogicalNetworkSearch :: Search(bool fBegin)
{
    // search for optimal network; return the highest log-prob
    // start from the initial network
#if 0
cout << "GenealogicalNetworkSearch :: Search()\n";
if( pnetworkOpt == NULL )
{
cout << "pnetworkOpt: NULL so need to initialize\n";
}
#endif
    // initialize if needed
    double probCurBest = GetCurrBestLogprob();
    if( pnetworkOpt == NULL )
    {
        pnetworkOpt = networkInit.Copy();
    }
    
    // now initialize the current best network
    if(fBegin==true)
    {
        GenealogicalNetworkLenOpt probInitCalc( *pnetworkOpt, listGeneTrees );
        probCurBest = probInitCalc.Optimize();
    }
//cout << "INITIAL network prob: " << probCurBest << endl;
    
    while(true)
    {
#if 0
cout << "--Processing current network (w/ prob: " << probCurBest << "): \n";
pnetworkOpt->DumpMargTrees(false);
pnetworkOpt->Dump();
#endif
        //
        vector<GenealogicalNetwork *> listNgbrNetsDist1;
        pnetworkOpt->RetriveNgbrNetsOneEvt( listNgbrNetsDist1 );
        
        // first find new networks
        vector<int> listNgbrNetPos;
        vector<GenealogicalNetwork *> listNgbrNetsDist1New;
        for(int i=0; i<(int)listNgbrNetsDist1.size(); ++i)
        {
            bool fFoundBefore = IsNetProcBefore( listNgbrNetsDist1[i] );
            bool fOGOK = IsNetworkOGGood( *listNgbrNetsDist1[i] );
            
            if( fFoundBefore == false && fOGOK )
            {
                listNgbrNetsDist1New.push_back( listNgbrNetsDist1[i] );
                listNgbrNetPos.push_back(i);
                
                // mark how many nets we have processed
                infoSearch.ProcNet( listNgbrNetsDist1[i] );
            }
            else
            {
                infoSearch.SkipNet( listNgbrNetsDist1[i] );
            }
        }
        
        
        // find ngbr networks (no adding new mix nodes)
        vector<double> listLogProbNgbrNets;
        
        if( numThreads > 1)
        {
            CalcProbNgbrNetworkMulthread(listNgbrNetsDist1New, listLogProbNgbrNets);
        }
        else
        {
            for(int i=0; i<(int)listNgbrNetsDist1New.size(); ++i)
            {
                int netIndex = listNgbrNetPos[i];
#if 0
cout << "&&&&&&&&&&&&&&&&&&Processing ngbr network " << netIndex << endl;
listNgbrNetsDist1[netIndex]->DumpMargTrees(false);
listNgbrNetsDist1[netIndex]->Dump();
#endif
                GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[netIndex], listGeneTrees);
                //double logprobBest = opt.Optimize();
                
                if( fFastSearch == false )
                {
                    double logprobBest = opt.Optimize();
                    listLogProbNgbrNets.push_back( logprobBest );
//cout << "(1a) Network ngbr " << i << ": optimized likelihood: " << logprobBest << endl;
                }
                else
                {
                    // YW: Feb 18, 2016: don't optimize branch length after a change of topology
                    double logprobChange = opt.CalcProb();
                    //listLogProbNgbrNets.push_back( logprobBest );
                    listLogProbNgbrNets.push_back(logprobChange);
//cout << "(1) Network ngbr " << i << ": un-optimized likelihood: " << logprobChange << endl;
                }
            }
        }
        
        // if nothing left, done
        int maxProbPos = -1;
        bool fContSearch = false;
        if( listLogProbNgbrNets.size() > 0 )
        {
            int maxProbPosStep = FindMaxValPositionFromList( listLogProbNgbrNets );
            double probBestNgbr = listLogProbNgbrNets[maxProbPosStep];
//cout << "!Best ngbr prob: " << probBestNgbr << endl;
            
            if( probBestNgbr >= probCurBest + log(MIN_INC_RATIO) )
            {
                maxProbPos = listNgbrNetPos[maxProbPosStep];
                
                // now optimize branch length of the selected one
                if( fFastSearch == false )
                {
                    probCurBest = probBestNgbr;
                }
                else
                {
                    GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[maxProbPos], listGeneTrees);
                    double probBestNgbrLenOpt = opt.Optimize();
                
                    // improvement found
                    //probCurBest = probBestNgbr;
                    probCurBest = probBestNgbrLenOpt;
                }
                
                delete pnetworkOpt;
                pnetworkOpt = listNgbrNetsDist1[maxProbPos];
                fContSearch = true;
                //cout << "UPDATING THE CURRENT NETWORK TO: ";
                //pnetworkOpt->Dump();
            }
        }
        
        for(int i=0; i<(int)listNgbrNetsDist1.size(); ++i)
        {
            if( i != maxProbPos || fContSearch == false )
            {
                delete listNgbrNetsDist1[i];
            }
        }
//cout << "@@@@@@@@@@@@@@@ Current best log-likelihood: " << probCurBest << endl;
//cout << "Best network: ";
//pnetworkOpt->DumpMargTrees(false);
        if( fContSearch == false )
        {
            break;
        }
    }
    
    // remember current best prob
    logprobBestCurr = probCurBest;
    
    return probCurBest;
}

//**********************************************************
// multi-threaded version

typedef struct
{
    int threadId;
    vector<GenealogicalNetwork *> *plistNgbrNetsDist;
    vector<PhylogenyTreeBasic *> *plistGeneTrees;
    int trStart;
    int trEnd;
    vector<double> listLogProbNgbrNetsLocal;
    //int tmpres;
} GTNetworkSearchThreadInfo;

static void *ThreadFuncGTNetSearch(void *ptr)
{
    //
    GTNetworkSearchThreadInfo *ptinfo = (GTNetworkSearchThreadInfo *)ptr;
//cout << "Starting a thread id: " << ptinfo->threadId << ", start: " << ptinfo->trStart << endl;
    //cout << "Start tree: " << ptinfo->trStart << ", end tree: " << ptinfo->trEnd << endl;
    // calculate prob for the range of trees we need to process
    for( int tr = ptinfo->trStart; tr <=ptinfo->trEnd; ++tr )
    {
        //cout << "thread " << ptinfo->threadId << ", i: " << i << ", j: " << j << endl;
        // YW: Feb 18, 2016: don't optimize branch length after a change of topology
        GenealogicalNetworkLenOpt opt( *((*(ptinfo->plistNgbrNetsDist))[tr]), *(ptinfo->plistGeneTrees) );
        opt.SetMultithread(false);
        double logprobChange = opt.CalcProb();
        //listLogProbNgbrNets.push_back( logprobBest );
        ptinfo->listLogProbNgbrNetsLocal.push_back(logprobChange);
    }
    //#endif
    //ptinfo->tmpres = CalcStuff( ptinfo->trStart, ptinfo->trEnd );
    
//cout << "Thread: [" << ptinfo->trStart << ", " << ptinfo->trEnd << "] is done\n";
    return NULL;
}


void GenealogicalNetworkSearch :: CalcProbNgbrNetworkMulthread(vector<GenealogicalNetwork *> &listNgbrNetsDist, vector<double> &listLogProbNgbrNets)
{
    YW_ASSERT_INFO( listNgbrNetsDist.size() > 0, "Cannot be empty" );
    //cout << "CalcProbMultithread: num of gene trees: " << listGeneTrees.size() << endl;
    // first find all trees that needs real computation
    vector<double> listNetProbs;
    listNetProbs.resize( listNgbrNetsDist.size() );
    
    
    // now do fresh prob calculation
    int numThreadsUse = numThreads;
    if(numThreadsUse > (int) listNgbrNetsDist.size()   )
    {
        numThreadsUse = (int)listNgbrNetsDist.size();
    }
    //cout << "Num of threas: " << numThreadsUse << endl;
    
    pthread_t* pid = new pthread_t[numThreadsUse];
    GTNetworkSearchThreadInfo *pThreadInfo = new GTNetworkSearchThreadInfo[numThreadsUse];
    
    // start the threads
    int numTreesPerThread = (int)listNgbrNetsDist.size()/numThreadsUse;
    YW_ASSERT_INFO(numTreesPerThread>=1, "Must have at least one tree to process");
    int numLeftOver = (int)listNgbrNetsDist.size() - numThreadsUse * numTreesPerThread ;
    YW_ASSERT_INFO( numLeftOver >= 0, "Must be non-negative");
    int trCurToProc = 0;
    for(int i=0;i<numThreadsUse;++i)
    {
        //cout << "Starting thread " << i << endl;
        // wait for all threads finishing
        pThreadInfo[i].threadId = i;
        pThreadInfo[i].trStart = trCurToProc;
        pThreadInfo[i].trEnd = trCurToProc + numTreesPerThread-1;
        trCurToProc += numTreesPerThread;
        // if there is leftover to do, add one more
        if( numLeftOver > 0 )
        {
            // add one more
            ++pThreadInfo[i].trEnd;
            ++trCurToProc;
            --numLeftOver;
        }
        //cout << "Range: " << pThreadInfo[i].trStart << ", " << pThreadInfo[i].trEnd << endl;
        pThreadInfo[i].plistGeneTrees = &listGeneTrees;
        pThreadInfo[i].plistNgbrNetsDist = &listNgbrNetsDist;
        
        // start thread
        int ret = pthread_create(&pid[i], NULL, &ThreadFuncGTNetSearch, (void *)&pThreadInfo[i]);
        if(ret)
        {
            cout << "Fatal error in creating pthread!" << endl;
            exit(1 );
        }
    }
    
    // free up resource
    for(int i=0;i<numThreadsUse;++i)
    {
        //wait for all threads finishing
        pthread_join(pid[i], NULL);
    }
    delete [] pid;
    //cout << "All threas are done.\n";
    
    //#if 0
    // collect results
    int index = 0;
    for( int i = 0; i<numThreadsUse; ++i )
    {
        for( int jj=0; jj<(int)pThreadInfo[i].listLogProbNgbrNetsLocal.size(); ++jj)
        {
            listNetProbs[index] = pThreadInfo[i].listLogProbNgbrNetsLocal[jj];
            ++index;
        }
    }
    //#endif
    delete [] pThreadInfo;

    
    //
    listLogProbNgbrNets = listNetProbs;
}




GenealogicalNetwork * GenealogicalNetworkSearch :: GetBestNet()
{
    return pnetworkOpt;
}

double GenealogicalNetworkSearch :: SearchWithNewMix()
{
    // search from current best network and adding one new mixing node
    YW_ASSERT_INFO( pnetworkOpt!=NULL, "Wrong: must be initialized" );
    
    double logprobBestCurrFromPrior = GetCurrBestLogprob();
    double probCurBest = logprobBestCurrFromPrior;
//cout << "^^^SearchWithNewMix:probCurBest (at entry)" << probCurBest << endl;
//cout << "CURRENT NETWORK: ";
//pnetworkOpt->Dump();
//pnetworkOpt->DumpMargTrees(false);
    //
    vector<GenealogicalNetwork *> listNgbrNetsDist1;
    YW_ASSERT_INFO(pnetworkOpt != NULL, "Must have already been initialized");
    pnetworkOpt->RetriveNgbrNetsOneNewMix( listNgbrNetsDist1 );
    
    // find ngbr networks (no adding new mix nodes)
    vector<double> listLogProbNgbrNets;
    vector<int> listNgbrNetPos;
    for(int i=0; i<(int)listNgbrNetsDist1.size(); ++i)
    {
//cout << "Processing network: ";
//listNgbrNetsDist1[i]->DumpMargTrees(false);
        bool fFoundBefore = IsNetProcBefore( listNgbrNetsDist1[i] );
        bool fOGOK = IsNetworkOGGood( *listNgbrNetsDist1[i] );
        
        if( fFoundBefore == false && fOGOK == true )
        {
//cout << "############################Processing network: ";
//cout << "Processing new good network: ";
//listNgbrNetsDist1[i]->DumpMargTrees(false);
            GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[i], listGeneTrees);
            // here, don't optimize over branch; rather, simply search for the single best network
            //double logprobBest = opt.CalcProb();
            //double logprobBest = opt.Optimize();        // optimize over branch length
//#if 0
            double logprobBest = opt.CalcProb();
//#endif
            listLogProbNgbrNets.push_back( logprobBest );
            listNgbrNetPos.push_back(i);
//cout << "(2) Network ngbr " << i << ": un-optimized likelihood: " << logprobBest << endl;
        }
        else
        {
            infoSearch.SkipNet( listNgbrNetsDist1[i] );;
        }
    }
    
    int maxProbPos = -1;
    if( listLogProbNgbrNets.size() > 0 )
    {
        int maxProbPosStep = FindMaxValPositionFromList( listLogProbNgbrNets );
        int maxProbPosStep1 = listNgbrNetPos[maxProbPosStep];
        
//cout << "In SearchWithNewMix: best mix net before opt has prob: " << listLogProbNgbrNets[maxProbPosStep] << ", network is: ";
//listNgbrNetsDist1[maxProbPosStep1]->DumpMargTrees(false);

        //double probBestNgbr = listLogProbNgbrNets[maxProbPosStep];
//#if 0
        
        // now optimize over the branch length
        GenealogicalNetworkLenOpt opt(*listNgbrNetsDist1[maxProbPosStep1], listGeneTrees);
        double probBestNgbr = opt.Optimize();
//#endif
//cout << "After optimization: the best ngbr net (w/ one new mix): " << probBestNgbr << ", logprobBestCurrFromPrior=" << logprobBestCurrFromPrior << endl;
//cout << "Marginal trees: ";
//listNgbrNetsDist1[maxProbPosStep1]->DumpMargTrees(false);
        //double probBestNgbr = listLogProbNgbrNets[maxProbPos];
        //if( probBestNgbr >= logprobBestCurrFromPrior + log(MIN_INC_RATIO) )
        if( probBestNgbr >= probCurBest + log(MIN_INC_RATIO) )
        {
            // improvement found
            probCurBest = probBestNgbr;
            maxProbPos = maxProbPosStep1;
            delete pnetworkOpt;
            pnetworkOpt = listNgbrNetsDist1[maxProbPos];
//cout << "UPDATING THE CURRENT NETWORK TO: prob=" << probCurBest << ": ";
//pnetworkOpt->Dump();
//pnetworkOpt->DumpMargTrees(false);
        }
        else
        {
            maxProbPos = -1;
        }
    }
    
    for(int i=0; i<(int)listNgbrNetsDist1.size(); ++i)
    {
        if( i != maxProbPos )
        {
            delete listNgbrNetsDist1[i];
        }
    }
//cout << "--@@@@@@@@@@@@@@@ Current best log-likelihood: " << probCurBest << endl;
//cout << "Best network: ";
//pnetworkOpt->DumpMargTrees(false);
    return probCurBest;
}

double GenealogicalNetworkSearch :: SearchTwoModes(int numMixNodesIn)
{
    // (1) search from current network to optimize
    // (2) add new mixing

    double probCurrBest = GetCurrBestLogprob();
    int numMixNodesBest = 0;
    bool fBegin=true;
    while(true)
    {
        double probStep = Search(fBegin);
        fBegin=false;
        probCurrBest = probStep;
        
        int numMixNodes = pnetworkOpt->GetNumMixNodes();
        if( numMixNodes >= maxNumMixNodes )
        {
            break;
        }
        
        if( numMixNodesIn > 0 && numMixNodes == numMixNodesIn )
        {
            break;
        }
        
//cout << "************* AFTER NGBR SEARCH, best network prob: " << probCurrBest << "   ";
//pnetworkOpt->DumpMargTrees(false);
        
        // YW: if the probabiity is small, stop
        //if( probStep < probCurrBest + log(MIN_INC_RATIO) )
        //{
        //    //probStep = probNewMix;
        //    break;
        //}

        
        // now try to add a new mix
        double probNewMix = SearchWithNewMix();
//cout << "Now searching for one more mixing node: initial prob: " << probNewMix << endl;
        
        numMixNodes = pnetworkOpt->GetNumMixNodes();
        if( numMixNodes <= numMixNodesBest && (numMixNodesIn < 0 || numMixNodesIn == numMixNodes) )
        {
            break;
        }
        numMixNodesBest = numMixNodes;
        probCurrBest = probNewMix;
        this->logprobBestCurr = probCurrBest;
        
        // YW: if the probabiity is small, stop
        //if( probNewMix < probStep + log(MIN_INC_RATIO) )
        //{
        //    //probStep = probNewMix;
        //    break;
        //}
        
//cout << "************* AFTER MIX SEARCH, best network: probNewMix: " << probNewMix << "    ";
//pnetworkOpt->DumpMargTrees(false);
        
    }
    return probCurrBest;
}

bool GenealogicalNetworkSearch :: IsNetProcBefore( GenealogicalNetwork *pnet)
{
    // for now checke very net
    return false;
    
    // check the net (find marginal trees); check what we have now; if not, add these marginalt rees
    //bool res = false;
    
    set<string> setMargTrNWs;
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    pnet->RetriveAllMarginalTrees( mapMargTreesWithFreq );
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo>::const_iterator it= mapMargTreesWithFreq.begin(); it != mapMargTreesWithFreq.end(); ++it )
    {
        // format: [freq] newick-format-tree
        string strNWTree = it->second.GetMargTree()->GetNewickSorted(false) ;
        //string strNWTreeNoBrLen = NewickUtils :: RemoveBrLenFromTree(strNWTree);
//cout << "Marginal tree (without converison: tree is " << strNWTreeNoBrLen << endl;
        //NewickUtils:: UpdateLabells( strNWTree, mapTaxonIdToUserId );
        //cout << "AFTER convert: tree is " << strNWTree << endl;
        setMargTrNWs.insert(strNWTree);
        it->second.FreeTree();
    }
#if 0
cout << "NETWORK TREES: \n";
for(set<string> :: iterator it = setMargTrNWs.begin(); it != setMargTrNWs.end(); ++it)
{
cout << "  " << *it << endl;
}
#endif
    
    if( setNetsMargtreesProc.find(setMargTrNWs) != setNetsMargtreesProc.end() )
    {
//cout << "Processed before and so SKIP....\n";
        return true;
    }
    else
    {
        setNetsMargtreesProc.insert( setMargTrNWs );
        return false;
    }

}

