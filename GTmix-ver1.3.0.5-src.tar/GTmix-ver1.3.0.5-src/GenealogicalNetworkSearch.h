//
//  GenealogicalNetworkSearch.h
//  
//
//  Created by Yufeng Wu on 1/7/16.
//  Search for optimal networks
//

#ifndef ____GenealogicalNetworkSearch__
#define ____GenealogicalNetworkSearch__

#include "GenealogicalNetwork.h"

class PhylogenyTreeBasic;

void SetFastSearch(bool f);

//***********************************************************************************
// Search info for optimal network

class GenealogicalNetworkSearchInfo
{
public:
    GenealogicalNetworkSearchInfo();
    void ProcNet(GenealogicalNetwork *pnet);
    void SkipNet(GenealogicalNetwork *pnet);
    int GetNumProcNets() const { return numNetsProcessed; }
    int GetNumSkippedNets() const { return numNetsSkipped; }
    void Dump() const;
    
private:
    int numNetsProcessed;
    int numNetsSkipped;
};

//***********************************************************************************
// Search for optimal network

class GenealogicalNetworkSearch
{
public:
    GenealogicalNetworkSearch(GenealogicalNetwork &netInit, vector<PhylogenyTreeBasic *> &listGeneTreesIn);
    ~GenealogicalNetworkSearch();
    double SearchWithNewMix();
    double Search(bool fBegin=false);
    double SearchTwoModes(int numMixNodes = -1);
    GenealogicalNetwork *GetBestNet();
    void SetMaxNumMixNodes(int mn) { maxNumMixNodes = mn; }
    int GetMaxNumMixNodes() const { return maxNumMixNodes; }
    int GetNumProcNets() const { return infoSearch.GetNumProcNets(); }
    int GetNumSkippedNets() const { return infoSearch.GetNumSkippedNets(); }
    static void SetNumThreads(int numThreads);
    static void SetOutgroup(int og);
    static int GetOutgroup();
    static bool IsNetworkOGGood( const GenealogicalNetwork &netTest );
    
private:
    double GetCurrBestLogprob() const { return logprobBestCurr; }
    bool IsNetProcBefore( GenealogicalNetwork *pnet);
    void CalcProbNgbrNetworkMulthread(vector<GenealogicalNetwork *> &listNgbrNetsDist, vector<double> &listLogProbNgbrNets);
    
    
    GenealogicalNetwork *pnetworkOpt;
    GenealogicalNetwork &networkInit;
    vector<PhylogenyTreeBasic *> &listGeneTrees;
    int maxNumMixNodes;
    double logprobBestCurr;
    GenealogicalNetworkSearchInfo infoSearch;
    set< set<string> > setNetsMargtreesProc;
    static int numThreads;
    static int taxonOutgroup;
};


#endif /* defined(____GenealogicalNetworkSearch__) */
