//
//  MultiBinaryMatrices.h
//  
//
//  Created by Yufeng Wu on 10/30/13.
//  Note: need binary matrix support
//

#ifndef ____MultiBinaryMatrices__
#define ____MultiBinaryMatrices__

#include <iostream>
#include "Utils3.h"
#include "BinaryMatrix.h"

//*********************************************************************
// Utilties to process a list of matrices

class MultiBinaryMatrices
{
public:
    MultiBinaryMatrices();
    
    bool ReadFromFile(const char *fileName);
    void Dump() const;
    int GetNumMats() const { return listInputMatrices.size(); }
    BinaryMatrix &GetMatrix(int i) { return listInputMatrices[i]; }
private:
    vector<BinaryMatrix> listInputMatrices;
};



#endif /* defined(____MultiBinaryMatrices__) */
