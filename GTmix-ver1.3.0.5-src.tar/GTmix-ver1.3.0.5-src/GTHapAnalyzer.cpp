//
//  GTHapAnalyzer.cpp
//  
//
//  Created by Yufeng Wu on 4/10/19.
//
//

#include "GTHapAnalyzer.hpp"
#include "Utils3.h"
#include "TreeBuilder.h"

//***********************************************************************************
// Build initial tree from haplotypes


ScaffoldTreeHapBuillder :: ScaffoldTreeHapBuillder( MultiBinaryMatrices &listHapMatsIn, const vector<vector<int> > &listPopRowsIn ) : listHapMats(listHapMatsIn), listPopRows(listPopRowsIn)
{
    ;
}

string ScaffoldTreeHapBuillder :: Build()
{
    PhyloDistance distPop;
    for(int p1=0; p1<GetNumPops(); ++p1)
    {
        for(int p2=p1+1; p2<GetNumPops(); ++p2)
        {
            double dist = CalcDistTwoPops(p1, p2);
cout << "For populations " << p1 << ", " << p2 << ", dist=" << dist << endl;
            distPop.SetDistance(p1, p2, dist);
        }
    }
    DistanceTreeBuilder treeBuilder(distPop);
    return treeBuilder.NJ();
}

double ScaffoldTreeHapBuillder :: CalcDistTwoPops(int p1, int p2)
{
    // assume: p1, p2 starts from index 0
    YW_ASSERT_INFO( p1 < (int)listPopRows.size(), "Population number overflow" );
    YW_ASSERT_INFO( p2 < (int)listPopRows.size(), "Population number overflow" );
    double distTot = 0.0;
    for(int i=0; i<(int)listPopRows[p1].size(); ++i)
    {
        for(int j=0; j<(int)listPopRows[p2].size(); ++j)
        {
            distTot += CalcDistTwoHaps( listPopRows[p1][i], listPopRows[p2][j] );
        }
    }
    return distTot/( listPopRows[p1].size()*listPopRows[p2].size() );
}

double ScaffoldTreeHapBuillder :: CalcDistTwoHaps(int h1, int h2)
{
    //
    double distTot = 0.0;
    for(int m=0; m<listHapMats.GetNumMats(); ++m)
    {
        //
        BinaryMatrix &matStep = listHapMats.GetMatrix(m);
        int numDiffs = matStep.GetDiffSitesForTwoRows( h1, h2 );
        double distStep = (1.0*numDiffs)/matStep.GetColNum();
        distTot += distStep;
    }
    return distTot/listHapMats.GetNumMats();
}



