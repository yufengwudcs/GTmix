//
//  GenealogicalNetworkProb.cpp
//  
//
//  Created by Yufeng Wu on 1/5/16.
//
//

#include "GenealogicalNetworkProb.h"
#include "GenealogicalNetwork.h"
#include "PhylogenyTreeBasic.h"
#include "GeneSpeciesTreeProb.h"
#include "ApproxGeneTreeProb.h"
#include "Utils3.h"
#include <cmath>
#include "UtilsNumerical.h"
#include "GenealogicalNetworkProbStore.h"
#include "pthread.h"

//***********************************************************************************
// Base class for calc prob of genealogical networks

GenericGeneSpeciesTreeProb * AbstractGenealogicalNetworkProb :: CreateProbCalcFor( MarginalTree *pMargTree, PhylogenyTreeBasic *pGeneTree )
{
#if 0
    string strNW;
    pGeneTree->ConsNewick(strNW);
    cout << "CreateProbCalcFor: margtree=" << pMargTree->GetNewick() << "  genetree: " << strNW << endl;
    cout << "margtree: dump: ";
    pMargTree->Dump();
    //cout << "genetree: dump:";
    //pGeneTree->Dump();
#endif
    
//SetVerbose(true);
    
//string strNW;
//pGeneTree->ConsNewick(strNW);
//cout << "CreateProbCalcFor: margtree=" << pMargTree->GetNewick() << "  genetree: " << strNW << endl;
    
    // for now, only do the exact prob computation
    //return new GeneSpeciesTreeProb( *pMargTree, *pGeneTree );
    return new ApproxGeneTreeProb( *pMargTree, *pGeneTree );
}

//***********************************************************************************
// Calc prob of genealogical networks

const int DEF_NUM_THREAD = 1;

int GenealogicalNetworkProb :: numThreads = DEF_NUM_THREAD;

GenealogicalNetworkProb :: GenealogicalNetworkProb(GenealogicalNetwork &netIn, vector<PhylogenyTreeBasic *> &listGeneTreesIn) : network(netIn), listGeneTrees(listGeneTreesIn), fMultithread(true), fFresh(false)
{
    //
    //Init();
}

GenealogicalNetworkProb :: ~GenealogicalNetworkProb()
{
    Clear();
}

void GenealogicalNetworkProb :: SetNumThreads(int t)
{
    numThreads = t;
}

void GenealogicalNetworkProb :: Init()
{
    Clear();
    
    // init the prob computing
    set<GenealogicalNetworkMTreeCode > setMTCodes;
    network.RetriveAllNetCode( setMTCodes );
    int indexNext = 0;
    for( set<GenealogicalNetworkMTreeCode > :: iterator it = setMTCodes.begin(); it != setMTCodes.end(); ++it )
    {
        //
        mapNetCodeIndex.insert( map<GenealogicalNetworkMTreeCode, int> :: value_type( *it, indexNext++ ) );
    }
    
    // create the prob computing tools
    CreateProbCalc();
    
    // init cache to garbage
    listCachedProbs.resize( listGeneTrees.size() );
    for(int i=0; i<(int)listCachedProbs.size(); ++i)
    {
        for(int j=0; j<(int)listMargTreesInNet.size(); ++j )
        {
            listCachedProbs[i].push_back(0.0);
        }
    }
}

void GenealogicalNetworkProb :: SetAllMargTreeDirty()
{
    //
    listMargTreeFresh.clear();
    for(int i=0; i<(int)listMargTreesInNet.size(); ++i)
    {
        listMargTreeFresh.push_back(false);
    }
}
void GenealogicalNetworkProb :: SetMargTreeDirty(int pos)
{
    //
    listMargTreeFresh[pos] = false;
}
bool GenealogicalNetworkProb :: IsMargTreeFresh(int pos)
{
    //
    return listMargTreeFresh[pos];
}
void GenealogicalNetworkProb :: SetAllMargTreeFresh()
{
    //
    listMargTreeFresh.clear();
    for(int i=0; i<(int)listMargTreesInNet.size(); ++i)
    {
        listMargTreeFresh.push_back(true);
    }
}
double GenealogicalNetworkProb :: GetCachedProbValFor(int gtIndex, int mtIndex)
{
    return listCachedProbs[gtIndex][mtIndex];
}
void GenealogicalNetworkProb :: SetCachedProbValFor(int gtIndex, int mtIndex, double val)
{
    //
    listCachedProbs[gtIndex][mtIndex] = val;
}

void GenealogicalNetworkProb :: Clear()
{
    for(int i=0; i<(int)listGenetreeProbPtrs.size(); ++i )
    {
        for(int j=0; j<(int)listGenetreeProbPtrs[i].size(); ++j)
        {
            if( listGenetreeProbPtrs[i][j] != NULL )
            {
                delete listGenetreeProbPtrs[i][j];
                listGenetreeProbPtrs[i][j] = NULL;
            }
        }
    }
    for(int i=0; i<(int)listMargTreesInNet.size(); ++i)
    {
        delete listMargTreesInNet[i];
    }
    listGenetreeProbPtrs.clear();
    listMargTreesInNet.clear();
    listGenetreeProbWts.clear();
    listMargTreeFresh.clear();
}

void GenealogicalNetworkProb :: ClearAt(int indexMT)
{
    //
    delete listMargTreesInNet[indexMT];
    for(int i=0; i<(int)listGenetreeProbPtrs.size(); ++i )
    {
        delete listGenetreeProbPtrs[i][indexMT];
        listGenetreeProbPtrs[i][indexMT] = NULL;
    }
}

void GenealogicalNetworkProb :: ReinitMargTree(int indexMT, MarginalTree *pMargTreeNew)
{
    //
    listMargTreesInNet[indexMT] = pMargTreeNew;
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
        YW_ASSERT_INFO(listGenetreeProbPtrs[i][indexMT] == NULL, "Must be null");
        
        // create the prob computing tool
        listGenetreeProbPtrs[i][indexMT] = CreateProbCalcFor( pMargTreeNew, listGeneTrees[i] ) ;
    }
    // make this marg tree dirty
    SetMargTreeDirty(indexMT);
}

bool GenealogicalNetworkProb :: IsInit()
{
    return listGenetreeProbPtrs.size() > 0;
}

double GenealogicalNetworkProb :: CalcProb()
{
    if( numThreads > 1 && fMultithread == true )
    {
        return CalcProbMultithread();
    }
    
//#if 0
    if( IsFresh() )
    {
        return CalcProbFromCached();
    }
    SetFresh(true);
//#endif
    
    Init();
    
    //
    //if( IsInit() == false )
    //{
    //    CreateProbCalc();
    //}
    map<string, double> mapTreeTopoProb;
    
    double res = 0.0;
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
        // get the tree topology to see if this topology has been computed before
        //string strNW;
        //listGeneTrees[i]->ConsNewickSorted(strNW);
        //if( mapTreeTopoProb.find(strNW) != mapTreeTopoProb.end() )
        //{
        //    double probToAdd = mapTreeTopoProb[strNW];
        //    res += probToAdd;
        //}
        //else
        {
            vector<double> listLogProbs;
            double logprobMax = MAX_NEG_DOUBLE_VAL;
            for(int j=0; j<(int)listGenetreeProbPtrs[i].size(); ++j)
            {
                // is this fresh? if so, just use cached value
                double logponetree;
                //if( IsMargTreeFresh( j ) == true )
                //{
    //cout << "CACHE:\n";
                //    //
                //    logponetree = GetCachedProbValFor(i, j);
                //}
                //else
                //{
    //cout << "COMPUTE:\n";
                logponetree = listGenetreeProbPtrs[i][j]->CalcLogProb();
                SetCachedProbValFor(i, j, logponetree);
                
                // clear out pcomputerprob afterwards
                delete listGenetreeProbPtrs[i][j];
                listGenetreeProbPtrs[i][j] = NULL;
                
                //}
                double wtStep = listGenetreeProbWts[j];
                logponetree += log(wtStep);
                if(logprobMax < logponetree )
                {
                    logprobMax = logponetree;
                }
                
                listLogProbs.push_back(logponetree);
    //cout << "Marginal tree: wt=" << wtStep << ", logponetree: " << logponetree << endl;
            }
            double logprobstep = GetLogSumOfLogs( listLogProbs );
            res += logprobstep;
            //mapTreeTopoProb[strNW] = logprobstep;
            //res += logprobMax;
        }
//string strNW;
//listGeneTrees[i]->ConsNewick(strNW);
//cout << "Gene tree: " << strNW << ", max prob: " << logprobMax << ", all prob: " << logprobstep << endl;
    }
//cout << "GenealogicalNetworkProb :: CalcProb: prob = " << res << endl;
    // after one round of computation: all marg trees become fresh
    SetAllMargTreeFresh();
    
    return res;
}

double GenealogicalNetworkProb :: CalcProbFromCached()
{
    //
    double res = 0.0;
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
        // get the tree topology to see if this topology has been computed before
        vector<double> listLogProbs;
        double logprobMax = MAX_NEG_DOUBLE_VAL;
        for(int j=0; j<(int)listGenetreeProbPtrs[i].size(); ++j)
        {
            // is this fresh? if so, just use cached value
            double logponetree = GetCachedProbValFor(i, j);
            double wtStep = listGenetreeProbWts[j];
            logponetree += log(wtStep);
            if(logprobMax < logponetree )
            {
                logprobMax = logponetree;
            }
            
            listLogProbs.push_back(logponetree);
            //cout << "Marginal tree: wt=" << wtStep << ", logponetree: " << logponetree << endl;
        }
        double logprobstep = GetLogSumOfLogs( listLogProbs );
        res += logprobstep;
    }
    
    return res;
}


//**********************************************************
// multi-threaded version

typedef struct
{
    int threadId;
    vector<PhylogenyTreeBasic *> *plistGeneTrees;
    vector< vector<GenericGeneSpeciesTreeProb *> > *plistGenetreeProbPtrs;
    vector<MarginalTree *> *plistMargTreesInNet;
    vector<double> *plistGenetreeProbWts;
    vector<pair<int,int> > *plistSTGTPairsToCalc;      // list of stuff to use
    int trStart;
    int trEnd;                              // range of trees for this particular tree to work with
    vector<double> listSTGTPairsProbsLocal;                       // computed loglikelihood of all the trees we use
    //int tmpres;
} GTCalcProbThreadInfo;

static void *ThreadFuncGTProbCalculator(void *ptr)
{
    //
    GTCalcProbThreadInfo *ptinfo = (GTCalcProbThreadInfo *)ptr;
//cout << "Starting a thread id: " << ptinfo->threadId << endl;
    //cout << "Start tree: " << ptinfo->trStart << ", end tree: " << ptinfo->trEnd << endl;
    // calculate prob for the range of trees we need to process
    for( int tr = ptinfo->trStart; tr <=ptinfo->trEnd; ++tr )
    {
        int i = (*(ptinfo->plistSTGTPairsToCalc))[tr].first;
        int j = (*(ptinfo->plistSTGTPairsToCalc))[tr].second;
        
        // mark thread id
        (*(ptinfo->plistGenetreeProbPtrs))[i][j]->SetThreadId( ptinfo->threadId );
        
        //cout << "thread " << ptinfo->threadId << ", i: " << i << ", j: " << j << endl;
        double logponetree = (*(ptinfo->plistGenetreeProbPtrs))[i][j]->CalcLogProb();
        
        GTTreeProbStore::Instance().AddTreeProb( *((*(ptinfo->plistMargTreesInNet))[j]), *((*(ptinfo->plistGeneTrees))[i]), logponetree );
        
        //double wtStep = (*(ptinfo->plistGenetreeProbWts))[j];
        //logponetree += log(wtStep);
        
        ptinfo->listSTGTPairsProbsLocal.push_back( logponetree );
    }
    //#endif
    //ptinfo->tmpres = CalcStuff( ptinfo->trStart, ptinfo->trEnd );
    
//cout << "Thread id " << ptinfo->threadId << ": [" << ptinfo->trStart << ", " << ptinfo->trEnd << "] is done\n";
    return NULL;
}


double GenealogicalNetworkProb :: CalcProbMultithread()
{
    //cout << "CalcProbMultithread: num of gene trees: " << listGeneTrees.size() << endl;
    // first find all trees that needs real computation
    vector<pair<int,int> > listSTGTPairsToCalc;
    vector<vector<double> > listSTGTPairsProbs;
    listSTGTPairsProbs.resize( listGeneTrees.size() );
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
        listSTGTPairsProbs[i].resize( listGenetreeProbPtrs[i].size() );
    }
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
        vector<double> listLogProbs;
        //double logprobMax = MAX_NEG_DOUBLE_VAL;
        for(int j=0; j<(int)listGenetreeProbPtrs[i].size(); ++j)
        {
            // is this fresh? if so, just use cached value
            double logponetree;
            
            bool fPreCalc = GTTreeProbStore::Instance().IsProbAlreadyComputed(*listMargTreesInNet[j], *listGeneTrees[i], logponetree);
            if( fPreCalc == false )
            {
                pair<int,int> pp(i,j);
                listSTGTPairsToCalc.push_back(pp);
            }
//#if 0
            else
            {
                double wtStep = listGenetreeProbWts[j];
                logponetree += log(wtStep);
                //if(logprobMax < logponetree )
                //{
                //    logprobMax = logponetree;
                //}
                listSTGTPairsProbs[i][j] = logponetree;
            }
//#endif
            //cout << "Marginal tree: wt=" << wtStep << ", logponetree: " << logponetree << endl;
        }
        //res += logprobMax;
        //string strNW;
        //listGeneTrees[i]->ConsNewick(strNW);
        //cout << "Gene tree: " << strNW << ", max prob: " << logprobMax << ", all prob: " << logprobstep << endl;
    }
    //cout << "listSTGTPairsToCalc: size: " << listSTGTPairsToCalc.size() << endl;
    
    if( listSTGTPairsToCalc.size() > 0 )
    {
        // now do fresh prob calculation
        int numThreadsUse = numThreads;
        if(numThreadsUse > (int) listSTGTPairsToCalc.size()   )
        {
            numThreadsUse = (int)listSTGTPairsToCalc.size();
        }
        //cout << "Num of threas: " << numThreadsUse << endl;
        
        pthread_t* pid = new pthread_t[numThreadsUse];
        GTCalcProbThreadInfo *pThreadInfo = new GTCalcProbThreadInfo[numThreadsUse];
        
        // start the threads
        int numTreesPerThread = (int)listSTGTPairsToCalc.size()/numThreadsUse;
        YW_ASSERT_INFO(numTreesPerThread>=1, "Must have at least one tree to process");
        int numLeftOver = (int)listSTGTPairsToCalc.size() - numThreadsUse * numTreesPerThread ;
        YW_ASSERT_INFO( numLeftOver >= 0, "Must be non-negative");
        int trCurToProc = 0;
        for(int i=0;i<numThreadsUse;++i)
        {
            //cout << "Starting thread " << i << endl;
            // wait for all threads finishing
            pThreadInfo[i].threadId = i;
            pThreadInfo[i].trStart = trCurToProc;
            pThreadInfo[i].trEnd = trCurToProc + numTreesPerThread-1;
            trCurToProc += numTreesPerThread;
            // if there is leftover to do, add one more
            if( numLeftOver > 0 )
            {
                // add one more
                ++pThreadInfo[i].trEnd;
                ++trCurToProc;
                --numLeftOver;
            }
            //cout << "Range: " << pThreadInfo[i].trStart << ", " << pThreadInfo[i].trEnd << endl;
            pThreadInfo[i].plistGeneTrees = &listGeneTrees;
            pThreadInfo[i].plistGenetreeProbPtrs = &listGenetreeProbPtrs;
            pThreadInfo[i].plistMargTreesInNet = &listMargTreesInNet;
            pThreadInfo[i].plistGenetreeProbWts = &listGenetreeProbWts;
            pThreadInfo[i].plistSTGTPairsToCalc = &listSTGTPairsToCalc;
            
            // start thread
            int ret = pthread_create(&pid[i], NULL, &ThreadFuncGTProbCalculator, (void *)&pThreadInfo[i]);
            if(ret)
            {
                cout << "Fatal error in creating pthread!" << endl;
                exit(1 );
            }
            
        }
        
        
        // free up resource
        for(int i=0;i<numThreadsUse;++i)
        {
            //wait for all threads finishing
            pthread_join(pid[i], NULL);
        }
        delete [] pid;
        //cout << "All threas are done.\n";
        
        //#if 0
        // collect results
        int index = 0;
        for( int i = 0; i<numThreadsUse; ++i )
        {
            for( int jj=0; jj<(int)pThreadInfo[i].listSTGTPairsProbsLocal.size(); ++jj)
            {
                int posi = listSTGTPairsToCalc[index].first;
                int posj = listSTGTPairsToCalc[index].second;
                double wtStep = listGenetreeProbWts[posj];
                listSTGTPairsProbs[posi][posj] = pThreadInfo[i].listSTGTPairsProbsLocal[jj]+log(wtStep);
                
//#if 0
                GTTreeProbStore::Instance().AddTreeProb( *listMargTreesInNet[posj], *listGeneTrees[posi], pThreadInfo[i].listSTGTPairsProbsLocal[jj] );
//#endif
                ++index;
            }
        }
        //#endif
        delete [] pThreadInfo;
    }
    
    
    // accumulate prob
    double res = 0.0;
    for(int i=0; i<(int)listSTGTPairsProbs.size(); ++i)
    {
        double logprobstep = GetLogSumOfLogs( listSTGTPairsProbs[i] );
        res += logprobstep;
    }
    
    //cout << "GenealogicalNetworkProb :: CalcProb: prob = " << res << endl;
    
    // after one round of computation: all marg trees become fresh
    SetAllMargTreeFresh();
    
    return res;
}



void GenealogicalNetworkProb :: CreateProbCalc()
{
    Clear();
    
    // retrieve marginal trees
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq ;
    network.RetriveAllMarginalTrees( mapMargTreesWithFreq );
    for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapMargTreesWithFreq.begin(); it != mapMargTreesWithFreq.end(); ++it )
    {
        listMargTreesInNet.push_back( it->second.GetMargTree() );
        listGenetreeProbWts.push_back( it->second.GetFreq() );
    }
    
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
        // create the prob computing tool
        vector<GenericGeneSpeciesTreeProb *> listGenProbSep;
        for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = mapMargTreesWithFreq.begin(); it != mapMargTreesWithFreq.end(); ++it )
        {
            listGenProbSep.push_back( CreateProbCalcFor( it->second.GetMargTree(), listGeneTrees[i] ) );
        }
    
        listGenetreeProbPtrs.push_back(listGenProbSep);
    }
    
    // to bein with, all marginal trees need to be processed
    SetAllMargTreeDirty();
}

//GenericGeneSpeciesTreeProb * GenealogicalNetworkProb :: CreateProbCalcFor( MarginalTree *pMargTree, PhylogenyTreeBasic *pGeneTree )
//{
//#if 0
//string strNW;
//pGeneTree->ConsNewick(strNW);
//cout << "CreateProbCalcFor: margtree=" << pMargTree->GetNewick() << "  genetree: " << strNW << endl;
//cout << "margtree: dump: ";
//pMargTree->Dump();
////cout << "genetree: dump:";
////pGeneTree->Dump();
//#endif
//
//    // for now, only do the exact prob computation
//    return new GeneSpeciesTreeProb( *pMargTree, *pGeneTree );
//}

void GenealogicalNetworkProb :: UpdateBranch( GenealogicalNetworkBranch *pBrChange )
{
#if 0
    // update branch length of a network branch and update the probability computation items
    map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> mapMargTreesWithFreq;
    network.RetriveAffectedMargTreesForChangedBr(pBrChange, mapMargTreesWithFreq);
    
    for(map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo>::iterator it= mapMargTreesWithFreq.begin(); it !=mapMargTreesWithFreq.end(); ++it)
    {
        //
        int indexCode = GetIndexForNetcode(it->first);
#if 0
cout << "UpdateBranch: margtree=" << it->second.GetMargTree()->GetNewick() << " for indexCode=" << indexCode << endl;
cout << "margtree: dump: ";
it->second.GetMargTree()->Dump();
#endif
        ClearAt(indexCode);
        ReinitMargTree(indexCode, it->second.GetMargTree() );
    }
#endif
    SetFresh(false);
}

void GenealogicalNetworkProb :: UpdateWts()
{
    //
    listGenetreeProbWts.clear();
    network.GetWtsForAllMargTrees(listGenetreeProbWts);
}

int GenealogicalNetworkProb :: GetIndexForNetcode( const GenealogicalNetworkMTreeCode &ncode )
{
    //
    YW_ASSERT_INFO( mapNetCodeIndex.find(ncode) != mapNetCodeIndex.end(), "Fail to find1" );
    return mapNetCodeIndex[ncode];
}

//***********************************************************************************
// Calc prob of genealogical networks


GenealogicalNetworkProbComposite :: GenealogicalNetworkProbComposite(GenealogicalNetwork &netIn, vector<PhylogenyTreeBasic *> &listGeneTreesIn, int szSubsetTaxaIn) : network(netIn), listGeneTrees(listGeneTreesIn), szSubsetTaxa(szSubsetTaxaIn)
{
    CreateSubGenetrees();
    
    CreateAllProbCalc();
}
GenealogicalNetworkProbComposite :: ~GenealogicalNetworkProbComposite()
{
    Clear();
    
    // free sub-gene trees
    for(int i=0; i<(int)listSubGeneTreesPtr.size(); ++i)
    {
        for(map<set<int>, PhylogenyTreeBasic * > :: iterator it= listSubGeneTreesPtr[i].begin(); it != listSubGeneTreesPtr[i].end(); ++it)
        {
            delete it->second;
        }
    }
    listSubGeneTreesPtr.clear();
}
double GenealogicalNetworkProbComposite :: CalcProb()
{
//cout << "GenealogicalNetworkProbComposite :: CalcProb() \n";
    //
    double res = 0.0;
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
//cout << "Processing gene tree " << i << endl;
        for( map<set<int>,vector<GenericGeneSpeciesTreeProb *> > :: iterator it = listGenetreeProbPtrs[i].begin(); it != listGenetreeProbPtrs[i].end(); ++it)
        {
            vector<double> listLogProbs;
            for(int j=0; j<(int)it->second.size(); ++j)
            {
                // is this fresh? if so, just use cached value
                double logponetree;
                //if( IsMargTreeFresh( j ) == true )
                //{
                //    //cout << "CACHE:\n";
                //    //
                //    logponetree = GetCachedProbValFor(i, j);
                //}
                //else
                //{
                //cout << "COMPUTE:\n";
                logponetree = it->second[j]->CalcLogProb();
                //SetCachedProbValFor(i, j, logponetree);
                //}
                double wtStep = GetSubMargTreeWt(it->first, j);                
//cout << "logponetree: " << logponetree << ", wtStep: " << wtStep << " for subset of taxa: ";
//DumpIntSet(it->first);
                
                logponetree += log(wtStep);
                listLogProbs.push_back(logponetree);
                //cout << "Marginal tree: wt=" << wtStep << ", logponetree: " << logponetree << endl;
            }
            res += GetLogSumOfLogs( listLogProbs );
        }
    }
//cout <<"Total log-likelihood: " << res << endl;
    return res;
}
double GenealogicalNetworkProbComposite :: GetSubMargTreeWt(const set<int> &staxa, int indexTree) const
{
    //
    GenealogicalNetworkProbComposite *pthis=const_cast<GenealogicalNetworkProbComposite *>(this);
    YW_ASSERT_INFO( listSubMargTreesWts.find(staxa) != listSubMargTreesWts.end(), "Fail to find" );
    return pthis->listSubMargTreesWts[staxa][indexTree];
}

void GenealogicalNetworkProbComposite :: UpdateBranch( GenealogicalNetworkBranch *pBrChange )
{
    // just update all trees
    CreateAllProbCalc();
}
void GenealogicalNetworkProbComposite :: UpdateWts()
{
    // same: update all trees
    CreateAllProbCalc();
}
void GenealogicalNetworkProbComposite :: Clear()
{
    //
    for(int i=0; i<(int)listGenetreeProbPtrs.size(); ++i )
    {
        for( map<set<int>,vector<GenericGeneSpeciesTreeProb *> > :: iterator it = listGenetreeProbPtrs[i].begin(); it != listGenetreeProbPtrs[i].end(); ++it  )
        {
            for(int j=0; j<(int)it->second.size(); ++j)
            {
                delete it->second[j];
            }
        }
    }
    for( map<set<int>, vector<MarginalTree *> > :: iterator it = listSubMargTreesInNet.begin(); it != listSubMargTreesInNet.end(); ++it )
    {
        for(int i=0; i<(int)it->second.size(); ++i)
        {
            delete it->second[i];
        }
    }
    listGenetreeProbPtrs.clear();
    listSubMargTreesInNet.clear();
    listSubMargTreesWts.clear();
}

void GenealogicalNetworkProbComposite :: CreateSubGenetrees()
{
    //
    listSubGeneTreesPtr.resize( listGeneTrees.size() );
    for(int i=0; i<(int)listGeneTrees.size(); ++i )
    {
//string strNW;
//listGeneTrees[i]->ConsNewick(strNW);
//cout << "CreateSubGenetrees: gene tree: " << strNW << endl;
        
        map<set<int>, PhylogenyTreeBasic * > mapSubtaxaToSubtree;
        
        vector<int> listLeafLabels;
        listGeneTrees[i]->GetAllLeafIntLabeles(listLeafLabels);
        set<int> listLeafLabelsSet;
        PopulateSetByVec(listLeafLabelsSet, listLeafLabels);
        if( listLeafLabelsSet.size() < szSubsetTaxa )
        {
            // not enough taxa to use, skip for now
            continue;
        }
        vector<int> listLeafLabelsSetVec;
        PopulateVecBySet(listLeafLabelsSetVec, listLeafLabelsSet);
        vector<int> posvec;
        GetFirstCombo( szSubsetTaxa, (int)listLeafLabelsSet.size(), posvec );
        while(true)
        {
            set<int> posvecss;
            PopulateSetByVec(posvecss, posvec);
            set<int> subsetTaxaStep;
            GetOrigSubset( listLeafLabelsSetVec, posvecss, subsetTaxaStep );
//cout << "CreateSubGenetrees: ";
//DumpIntSet(subsetTaxaStep);
            set<string> setTaxaStr;
            for(set<int> :: iterator it = subsetTaxaStep.begin(); it != subsetTaxaStep.end(); ++it)
            {
                char buf[100];
                sprintf(buf, "%d", *it);
                string strbuf(buf);
                setTaxaStr.insert(strbuf);
            }
            PhylogenyTreeBasic *psubtree = new PhylogenyTreeBasic;
            listGeneTrees[i]->CreatePhyTreeFromLeavesWithLabels( setTaxaStr, *psubtree, true );
//string strNW2;
//psubtree->ConsNewick(strNW2);
//cout << "CreateSubGenetrees: sub gene tree: " << strNW2 << endl;
            mapSubtaxaToSubtree.insert( map<set<int>, PhylogenyTreeBasic * > :: value_type(subsetTaxaStep, psubtree) );
            
            if( GetNextCombo( szSubsetTaxa, (int)listLeafLabelsSet.size(), posvec ) == false )
            {
                break;
            }
        }
        
        listSubGeneTreesPtr[i] = mapSubtaxaToSubtree;
    }
}

PhylogenyTreeBasic * GenealogicalNetworkProbComposite :: GetSubGenetree( int gindex, const set<int> &staxa ) const
{
    //
    GenealogicalNetworkProbComposite *pthis=const_cast<GenealogicalNetworkProbComposite *>(this);
    YW_ASSERT_INFO( gindex <(int)listSubGeneTreesPtr.size(), "Overflow" );
    if( pthis->listSubGeneTreesPtr[gindex].find(staxa) == pthis->listSubGeneTreesPtr[gindex].end() )
    {
        // this subet not there
        return NULL;
    }
    else
    {
        return pthis->listSubGeneTreesPtr[gindex][staxa];
    }
}

void GenealogicalNetworkProbComposite :: CreateAllProbCalc()
{
    // assume all marginal tree has been set
    Clear();
    
    // retrieve marginal trees
    map<set<int>, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> > mapSubMargTreesWithFreq ;
    network.RetriveAllSubMarginalTrees(szSubsetTaxa, mapSubMargTreesWithFreq );
    for( map<set<int>, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> > :: iterator it0= mapSubMargTreesWithFreq.begin(); it0 != mapSubMargTreesWithFreq.end(); ++it0 )
    {
        vector<MarginalTree *> listSubMargTreesInNetStep;
        vector<double> listSubMargTreesWtsStep;
        for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = it0->second.begin(); it != it0->second.end(); ++it )
        {
            listSubMargTreesInNetStep.push_back( it->second.GetMargTree() );
            listSubMargTreesWtsStep.push_back( it->second.GetFreq() );
        }
        listSubMargTreesInNet.insert( map<set<int>, vector<MarginalTree *> > :: value_type( it0->first, listSubMargTreesInNetStep ) );
        listSubMargTreesWts.insert( map<set<int>, vector<double> > :: value_type(it0->first, listSubMargTreesWtsStep)  );
    }
    
    for(int i=0; i<(int)listGeneTrees.size(); ++i)
    {
//string strNW;
//listGeneTrees[i]->ConsNewick(strNW);
//cout << "Processing gene tree: " << strNW << endl;
        // create the prob computing tool
        map<set<int>,vector<GenericGeneSpeciesTreeProb *> > mapProbCalc;
        for( map<set<int>, map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> > :: iterator it0 = mapSubMargTreesWithFreq.begin(); it0 != mapSubMargTreesWithFreq.end(); ++it0)
        {
//cout << "Processing subset of taxa: ";
//DumpIntSet(it0->first);
            PhylogenyTreeBasic *psubtreePtr = GetSubGenetree( i, it0->first );
            YW_ASSERT_INFO(psubtreePtr != NULL, "Handling null subtree ptrs has not been implemented yet");
            
            vector<GenericGeneSpeciesTreeProb *> listGenProbSep;
            for( map<GenealogicalNetworkMTreeCode, GenealogicalNetworkMTreeInfo> :: iterator it = it0->second.begin(); it != it0->second.end(); ++it )
            {
                listGenProbSep.push_back( CreateProbCalcFor( it->second.GetMargTree(), psubtreePtr ) );
            }
            mapProbCalc.insert( map<set<int>,vector<GenericGeneSpeciesTreeProb *> > :: value_type( it0->first, listGenProbSep ) );
        }
        
        listGenetreeProbPtrs.push_back(mapProbCalc);
    }

}



