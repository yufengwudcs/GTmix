#!/bin/bash -f
# this is a tutorial for how to run GTmix with haplotypes simulated by Hudson's ms
# note: I hard-coded the filenames in this tuotiral. You should revise it to make it run on your files

# Before running this tutorial, make sure the following files are under the current directory:
# (i) gtmix (you either build from source or use the pre-built executable)
# (ii) treepicker executable that works for your system
# (iii) RentPlus.jar (distributed as part of GTmix)

# Caution: all intermediate files will be named with "tmp." as prefix
# when this tutorial script is run, all files with this prefixes under the current directory will be removed

coreFile="20x50x50x50-4p4a-og-t0.1.net3.1.trace"
numdata=50
numtreelocus=1
singlehapfile="tmp.$coreFile"
singlehapfileRPD="$singlehapfile.rentplus" 
singleinftreefile="$singlehapfileRPD.trees"
singleinftreefilechosen="$singleinftreefiledec1chosen"
outputChosenTreeFile="tmp.treeschosen-$coreFile.trees"

# clean up first
rm -f $outputChosenTreeFile
rm -f tmp.*

# Step one: run RENT+ on haplotypes to infer local trees
# there are 10 loci in the ms output file; run one by one
echo "STEP ONE: infer local trees from haplotypes"
k=1
for ((k=1; k<=$numdata; k++))
do
  echo "Data $k"
  awk -f ms2single-sitepos.awk n=$k  $coreFile  > $singlehapfile.$k
  java -jar RentPlus.jar $singlehapfile.$k > $singlehapfileRPD.$k
  rm $singlehapfile.$k.Tmrcas
  awk -f dumpFieldFirstFieldMatch.awk fs=1 fo=6 s="At" $singlehapfileRPD.$k > $singleinftreefile.$k
  rm $singlehapfileRPD.$k
done

# Step two: sample some local trees from each locus
echo "STEP TWO: pick local trees from each locus to form the tree files to GTmix"
for ((k=1; k<=$numdata; k++))
do
  echo "Data $k"
  ./treepicker $singleinftreefile.$k $singlehapfile.$k $numtreelocus > $singleinftreefilechosen.$k 
  cat $singleinftreefilechosen.$k  >> $outputChosenTreeFile
  rm $singleinftreefilechosen.$k
  rm $singlehapfile.$k
  rm $singleinftreefile.$k
  rm $singlehapfile.$k.trees
done

# Step three: run GTmix
echo "STEP THREE: finally run GTmix"
./gtmix -P listPopInfo-p5-a4.txt $outputChosenTreeFile
